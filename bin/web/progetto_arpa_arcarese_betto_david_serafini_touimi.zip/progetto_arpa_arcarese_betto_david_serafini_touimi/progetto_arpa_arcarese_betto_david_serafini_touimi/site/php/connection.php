<?php
    $servername = "172.16.1.92";
    $username = "gruppo3";
    $password = "canopo";
    $dbname = "arpav3";

    /*$servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "arpav3";*/

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }  // Check connection
?>