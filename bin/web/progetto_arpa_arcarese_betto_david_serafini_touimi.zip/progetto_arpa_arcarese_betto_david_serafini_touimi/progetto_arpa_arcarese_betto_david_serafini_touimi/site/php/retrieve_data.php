<?php
    include "connection.php";
    $postData = json_decode(file_get_contents("php://input"));
    $nome = $postData->nome;
    $data = [];
    $sql = "SELECT AVG(d.PMx) as N
    FROM dati d INNER JOIN localita l ON d.Centralina = l.codseqst
    WHERE l.nome = '$nome'
    GROUP BY l.nome, substring(dataR,4,2)";
    $res = $conn->query($sql);
        if ($res){
            while ($row = $res->fetch_assoc()) {
                $data[] = $row['N'];
            }
            $conn->close();
        }
    header('Content-Type: application/json');
    echo json_encode($data);
?>