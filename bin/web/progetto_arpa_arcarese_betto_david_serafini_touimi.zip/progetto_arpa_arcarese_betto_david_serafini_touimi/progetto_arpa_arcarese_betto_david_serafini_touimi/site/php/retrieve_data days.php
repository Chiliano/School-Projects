<?php
    include "connection.php";
    $postData = json_decode(file_get_contents("php://input"));
    $nome = $postData->nome;
    $data = [];
    $sql="SELECT d.PMx
    FROM dati d INNER JOIN (SELECT DISTINCT * FROM localita) l ON d.Centralina = l.codseqst
    WHERE l.nome = '$nome'
    ORDER BY d.DataR DESC
    LIMIT 7";
    $res = $conn->query($sql);
        if ($res){
            while ($row = $res->fetch_assoc()) {
                $data[] = $row['PMx'];
            }
            $conn->close();
        }
    header('Content-Type: application/json');
    echo json_encode($data);
?>