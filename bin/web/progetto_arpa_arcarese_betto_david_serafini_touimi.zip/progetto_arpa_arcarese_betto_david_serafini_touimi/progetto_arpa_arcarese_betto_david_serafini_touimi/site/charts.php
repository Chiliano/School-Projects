<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="./images/logo.png">
    <title>PMX Dashboard</title>

    <!-- Montserrat Font -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/styles.css">
  </head>

  <body >
    <div  class="grid-container">

      <!-- Header -->
      <header class="header">
        <div class="menu-icon" onclick="openSidebar()">
          <span class="material-icons-outlined">menu</span>
        </div>
      </header>
      <!-- End Header -->

      <!-- Sidebar -->
      <aside id="sidebar">
        <div class="sidebar-title">
          <div class="sidebar-brand">
            <a href="./index.html"><img src="./images/logo.png" width="200px"></a>
          </div>
          <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
        </div>

        <ul class="sidebar-list">
          <li class="sidebar-list-item" onclick="location.href='./charts.php';">
            <a href="./charts.php">
              <span class="material-icons-outlined"></span> Grafici
            </a>
          </li>
          <li class="sidebar-list-item" onclick="window.open('https://docs.google.com/spreadsheets/d/1Wo3TsYelfQi5wsPPch5FYhywZ_HeuTHUbfHaOZysOOc/edit#gid=0', 'blank')">
            <a href="https://docs.google.com/spreadsheets/d/1Wo3TsYelfQi5wsPPch5FYhywZ_HeuTHUbfHaOZysOOc/edit#gid=0"  target="_blank">
              <span class="material-icons-outlined"></span> Matematica
            </a>
          </li>
          <li class="sidebar-list-item" onclick="location.href='./civic_education.html';">
            <a href="./civic_education.html">
              <span class="material-icons-outlined"></span> Educazione civica
            </a>
          </li>
        </ul>
      </aside>
      <!-- End Sidebar -->
      
      <!-- Main -->
      <class class="main-container">
        <h2>Charts</h2>
        <select class="selezione" onchange="changeData()" id="selezione-centraline">
        <?php
          include "./php/connection.php";
          $sql = "SELECT DISTINCT l.nome FROM localita l INNER JOIN dati d ON d.Centralina = l.codseqst";
          $res = $conn->query($sql);
          if ($res) {
              while ($row = $res->fetch_assoc()) {
                  echo("<option value='{$row['nome']}'>{$row['nome']}</options>");
              }
              $conn->close();
            }
          ?>
        </select>
        <div id="area-chart"></div>
        <div id="area-chart2"></div>
        <div class="main-title"></div>
      </class>

    <!-- ApexCharts JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/apexcharts/3.35.5/apexcharts.min.js"></script>
    <!-- Custom JS -->
    <script src="./js/scripts.js"></script>

    </body>
</html>
