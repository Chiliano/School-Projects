// Define a variable to store the chart instance
let areaChart;
let areaChart2;

// Define a function to retrieve data from the server
function retrieveData() {
  const user = { "nome": document.getElementById("selezione-centraline").value };
  try {
    return fetch("php/retrieve_data.php", {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(user)
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        return response.json();
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
        return []; // Return an empty array in case of an error
      });
  } catch (error) {
    console.error('Error retrieving data:', error);
    return []; // Return an empty array in case of an error
  }
}
function retrieveData2() {
  const user = { "nome": document.getElementById("selezione-centraline").value };
  try {
    return fetch("php/retrieve_data_days.php", {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(user)
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        return response.json();
      })
      .catch(error => {
        console.error('Error retrieving data:', error);
        return []; // Return an empty array in case of an error
      });
  } catch (error) {
    console.error('Error retrieving data:', error);
    return []; // Return an empty array in case of an error
  }
}


// Define a function to update the chart with the retrieved data
function updateChartWithData(data) {
  // Check if chart instance exists
  if (areaChart) {
    areaChart.updateSeries([{ data: data.map(x => parseInt(x)) }], true);
  } else {
    console.error('Chart instance not found');
  }
}
function updateChart2WithData(data) {
  // Check if chart instance exists
  if (areaChart2) {
    areaChart2.updateSeries([{ data: data.map(x => parseInt(x)) }]);
  } else {
    console.error('Chart instance not found');
  }
}

// Call retrieveData() to fetch data and update the chart
function updateChart() {
  retrieveData().then(data => {
    if (data) {
      updateChartWithData(data);
    } else {
      // Handle case when no data is retrieved
      console.error('No data retrieved');
    }
  }).catch(error => {
    // Handle fetch error
    console.error('Error retrieving data:', error);
  });
  retrieveData2().then(data => {
    if (data) {
      updateChart2WithData(data);
    } else {
      // Handle case when no data is retrieved
      console.error('No data retrieved');
    }
  }).catch(error => {
    // Handle fetch error
    console.error('Error retrieving data:', error);
  });
}

// Function to change data based on selection
function changeData() {
  const selectObject = document.getElementById("selezione-centraline");
  const selectedValue = selectObject.value;
  if (selectedValue) {
    retrieveData(selectedValue).then(data => {
      if (data) {
        updateChartWithData(data);
      } else {
        // Handle case when no data is retrieved
        console.error('No data retrieved');
      }
    }).catch(error => {
      // Handle fetch error
      console.error('Error retrieving data:', error);
    });
    retrieveData2(selectedValue).then(data => {
      if (data) {
        updateChart2WithData(data);
      } else {
        // Handle case when no data is retrieved
        console.error('No data retrieved');
      }
    }).catch(error => {
      // Handle fetch error
      console.error('Error retrieving data:', error);
    });
  }
}

// AREA CHART
const areaChartOptions = {
  series: [
    {
      name: "µg/m3",
      data: [], // Placeholder for data
    },
  ],
  chart: {
    type: 'area',
    background: 'transparent',
    height: 350,
    stacked: false,
    toolbar: {
      show: false,
    },
  },
  colors: ['#00ab57'],
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Set', 'Oct', 'Nov', 'Dec'],
  dataLabels: {
    enabled: false,
  },
  fill: {
    gradient: {
      opacityFrom: 0.4,
      opacityTo: 0.1,
      shadeIntensity: 1,
      stops: [0, 100],
      type: 'vertical',
    },
    type: 'gradient',
  },
  grid: {
    borderColor: '#55596e',
    yaxis: {
      lines: {
        show: true,
      },
    },
    xaxis: {
      lines: {
        show: true,
      },
    },
  },
  legend: {
    labels: {
      colors: '#f5f7ff',
    },
    show: true,
    position: 'top',
  },
  markers: {
    size: 6,
    strokeColors: '#1b2635',
    strokeWidth: 3,
  },
  stroke: {
    curve: 'smooth',
  },
  xaxis: {
    title: {
      text: 'Months',
      style: {
        color: '#f5f7ff',
      },
    },
    axisBorder: {
      color: '#55596e',
      show: true,
    },
    axisTicks: {
      color: '#55596e',
      show: true,
    },
    labels: {
      offsetY: 5,
      style: {
        colors: '#f5f7ff',
      },
    },
  },
  yaxis: [
    {
      title: {
        text: 'Media Polveri Mensile',
        style: {
          color: '#f5f7ff',
        },
      },
      labels: {
        style: {
          colors: ['#f5f7ff'],
        },
      },
    },
  ],
  tooltip: {
    shared: true,
    intersect: false,
    theme: 'dark',
  },
};
const areaChart2Options = {
  series: [
    {
      name: "µg/m3",
      data: [], // Placeholder for data
    },
  ],
  chart: {
    type: 'area',
    background: 'transparent',
    height: 350,
    stacked: false,
    toolbar: {
      show: false,
    },
  },
  colors: ['#00ab57'],
  labels: ['Day1', 'Day2', 'Day3', 'Day4', 'Day5', 'Day6', 'Day7'],
  dataLabels: {
    enabled: false,
  },
  fill: {
    gradient: {
      opacityFrom: 0.4,
      opacityTo: 0.1,
      shadeIntensity: 1,
      stops: [0, 100],
      type: 'vertical',
    },
    type: 'gradient',
  },
  grid: {
    borderColor: '#55596e',
    yaxis: {
      lines: {
        show: true,
      },
    },
    xaxis: {
      lines: {
        show: true,
      },
    },
  },
  legend: {
    labels: {
      colors: '#f5f7ff',
    },
    show: true,
    position: 'top',
  },
  markers: {
    size: 6,
    strokeColors: '#1b2635',
    strokeWidth: 3,
  },
  stroke: {
    curve: 'smooth',
  },
  xaxis: {
    title: {
      text: 'Last 7 days',
      style: {
        color: '#f5f7ff',
      },
    },
    axisBorder: {
      color: '#55596e',
      show: true,
    },
    axisTicks: {
      color: '#55596e',
      show: true,
    },
    labels: {
      offsetY: 5,
      style: {
        colors: '#f5f7ff',
      },
    },
  },
  yaxis: [
    {
      title: {
        text: 'Polveri Giornaliere',
        style: {
          color: '#f5f7ff',
        },
      },
      labels: {
        style: {
          colors: ['#f5f7ff'],
        },
      },
    },
  ],
  tooltip: {
    shared: true,
    intersect: false,
    theme: 'dark',
  },
};

// Initialize the chart instance
areaChart = new ApexCharts(
  document.querySelector('#area-chart'),
  areaChartOptions
);
areaChart2 = new ApexCharts(
  document.querySelector('#area-chart2'),
  areaChart2Options
);
areaChart.render();
areaChart2.render();


//functions used to redirect the user
function charts() {
  window.location.href = '../charts.php'
}

function math() {
  window.location.href = '.math.html'
}

// Call updateChart() when the page loads or whenever you want to update the chart
updateChart();

// Event listener to call changeData() when the selection in the dropdown changes
document.getElementById("selezione-centraline").addEventListener("change", changeData);

// SDIDE BAR
let sidebarOpen = false;
const sidebar = document.getElementById('sidebar');
function openSidebar() {
  if (!sidebarOpen) {
    sidebar.classList.add('sidebar-responsive');
    sidebarOpen = true;
  }
}

function closeSidebar() {
  if (sidebarOpen) {
    sidebar.classList.remove('sidebar-responsive');
    sidebarOpen = false;
  }
} 