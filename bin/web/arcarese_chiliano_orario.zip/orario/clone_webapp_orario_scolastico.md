# WEBAPP ORARIO SCOLASTICO

0. [Analisi API](#analisi)
1. [Raccolta dati](#raccolta-dati)
2. [Sistema di cache](#sistema-di-cache)
3. [UI](#ui)
4. [UX](#ux)
5. []()
6. []()
7. []()