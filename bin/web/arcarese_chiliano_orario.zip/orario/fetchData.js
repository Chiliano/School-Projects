const APIQuery = () => {
    console.log("------------------START-QUERY-----------------")
    const entity = document.getElementById("entity").value.toUpperCase()
    let apiUrl = "https://apps.marconivr.it/orario/api.php"
    let queryString = recognizeQueryObj(entity, apiUrl)
    const expireTime = 60*60 // 1hrs
    document.getElementById("msg").textContent = ""
    console.log(apiUrl + queryString)

    if (localStorage.getItem(entity)) {
        let recordDate = new Date().getTime() - localStorage.getItem(entity).split(",")[0]
        if (expireTime > recordDate) {
            fetchData(entity, apiUrl + queryString)
        } else
            console.log("Loading cached data...")
            displayDataTables(localStorage.getItem(entity), queryString)
    } else {
        fetchData(entity, apiUrl + queryString)
    }
}


function recognizeQueryObj(entity, url) {
    console.log("Recognizing entity's family...")
    entityArray = entity.split(" ")
    var profList = [
        "ADAMOLI PAOLO ","ALARIO MAURIZIO ","ALBERTINI MARIA LUIS ","AMBROSI ACHILLE ","APREA MARCO ","ARENA AGATA ","ARTUSO FEDERICA ",
        "AVESANI ORIETTA ","AZZINI SERGIO ","BAGHINI PAOLA SOFIA ","BALDOVIN ANTONIETTA ","BARALDI ELENA ","BARBATO GAETANO ",
        "BATTAGLIA ELENA RITA ","BATTAGLIA STEFANIA ","BELLAMOLI LUISA ","BELLINI GIANNI ","BENEDETTI DANIELA ","BENEDETTI SIMONE ",
        "BERNARDONI MASSIMO ","BERTASINI JENNIFER ","BIANCHI PAOLO ","BIANCO ANNUNZIATA ","BILEDDO ANTONINO ","BISSOLI FRANCO GIUSE ",
        "BISSOLI GRAZIANO ","BOLDRIN LAURA ","BONAMINI FRANCESCA ","BONAMINI GIULIO ","BONANI MADDALENA ","BONAVITA TOMMASO ","BORTOLAZZI MIRKO ",
        "BOSCAINI MAURIZIO ","BOTTACINI MARINA ","BOUCHE GIULIA ","BOZZERLA SILVIA ","BRANCATO GIUSY ","BRANDO ROSINA ","BUCCHERI BARBARA ",
        "BUDETTA VALENTINA ","BURATO ALBERTO ","BUZZONE MARIA FRANCE ","CACCAMO VIVIANA ","CARBONE LUIGI ","CARDONE GIUSEPPE ","CARELLO NICOLO ",
        "CARLETTI CLAUDIA ","CIRRITO MARCO ","COBELLO GRAZIA ","COLOGNESE CHIARA ","COLOMBANA SARA ","COLOMBARI MARIA TERE ","CONTE FEDERICO ",
        "COPELLI PATRIZIA ","COPPOLA MICHELA ","CORDIOLI AGNESE ","DAL BARCO ANDREA ","DALLA RIVA FRANCESCO ","DALLE DONNE ANITA ","DANESE BENIAMINO ",
        "DE CARLI LORENZO ","DE CONTI MARTINA ","DE CRISTOFARO MATTIA ","DE FAZIO GIOVANNA ","DE TOFFOLI FRANCESCA ","DESTRI CLAUDIO ","DESUMMA GIANFRANCO ",
        "DI BELLA VINCENZO FR ","DI STEFANO GIULIA GR ","DIPIETRO IVANA ","DONATELLO ROBERTO ","DRAGO NICOLA ","FASOLI GIUSEPPE ","FERRARI BARBARA ",
        "FICHERA DEBORA ","FRANZOGNA SERGIO ","GACCIONE STEFANO ","GAIONI CLAUDIO ","GECCHERLE MICHELE ","GRASSO MARIO ","GUERRA LUCIA ","IMBERTI GIOVANNA ",
        "IULIANO ROSANGELA ","LAITI CECILIA ","LANDRO BARBARA ","LANZA ANTONELLA ","LATELLA PAOLO ","LAVAGNINI LORENZO ","LEGATO ANTONELLA ","LEONE BRUNO ",
        "LIOTTA EMILIA ","LONARDI FABIOLA ","LONGAFELD MARCO ","LOVATO MARA ","LUCCHINI GIACOMO ","MAGRIN ANNA ","MALACCHINI DANIELA ","MARCHESINI CINZIA ",
        "MARTINI MARCO ","MASCIAVE JEAN MARC ","MASSELLA MARIANGELA ","MECCI EMANUELE ","MILORDO COSIMINO ","MONTAGNI PATRIZIA ","MONTANO ELENA ",
        "MONTI ELEONORA ","MORANDIN ANDREA ","MORANDINI CRISTIAN ","MORETTI CLAUDIA ","MURAGLIA SAVINO ","MURTAS STEFANO ","NATOLI AGNESE ",
        "OLIVATO LUCIA ","ONGARO CARLO ALBERTO ","PADOVANI CHIARA ","PALERMO EVA ","PARISI GIUSEPPE ","PERNA CARMINE ","PESCHECHERA MARIA GI ",
        "PETROSINO RAFFAELLA ","PIACENTINI LUCA ","PINTORI MARIA IMMACO ","PIZZEGHELLA ANDREA ","POCLENER MATTEO ","PRESTIA STEFANIA ","PRIMAVERA CATIA ",
        "PROVOLO SERGIO ","PUZZO GABRIELLA ","RANDAZZO MARIA CARME ","RAPISARDA LUIGI ","REMOLINI ALBERTO ","RIGATO ALBERTO ","RIGGI LUIGI ALESSAND ",
        "RIZZINI NICOLA ","ROLLIN ANTONIO ","RONZA FRANCESCO ","ROSSANO LORENZO ","RUGOLOTTO MANUEL ","SAGLIA SARA ","SANGIORGIO SILVIA ","SANSONE MARIA GRAZIA ",
        "SANTOSUOSSO OTINO ","SARDINA FRANCESCO ","SATURNINO DANIELA ","SAVIANO SIMONE ","SBAMPATO DANIELE ","SCIENZA MATTEO ","SEGATO GIULIO ","SETTE ANTONIO ",
        "SICILIANO FRANCESCO ","SILEO GIORGIO ","SOTTILE SALVATORE ","SPERA MARCO ","STECCANELLA PAOLA CH ","TACCHELLA PAOLO ","TANTALO REMO ","TANTIMONACO IVAN ",
        "TARALLO PASQUALE ","TARZIA DONATELLA ","TINNIRELLO FRANCA ","TOMELLERI PAOLO ","TOMMASINI NICOLA ","TORNUSCIOLO DANTE ","TOZZI GABRIELE ","UGOLI CATERINA ",
        "VALENTINI SILVIA ","VALENZA GIAN PAOLO ","VENTURI IRENE ","VICENTINI ELISA ","VIVIANI MARIA IMMACO ","ZAMBELLI ENRICA ","ZAMPIERI AMEDEO ","ZANETTI MARTA ",
        "ZANONCELLI DANIELA ","ZANOTTI LORETTA ","ZANTEDESCHI DANIELA ","ZATTONI ANDREA ","ZEMINIAN STEFANO ","ZENARI MICHELE ","ZIMBONE AFRA ","ZOCCA DIEGO ",
        "ZULINI LUCA ","ZULLO STEFANO ","ZUPPANI SARA "
    ]
    if ((entity.startsWith("A") || entity.startsWith("L")) && entity.length == 4)
        return `?room=${entity}`
    else if (/^\d/.test(entity))
        return `?class=${entity}`
    else if (!profList.includes(entity)) {
        let filteredProf = Array.from(profList.filter(prof => prof.includes(entityArray[0])))
        filteredProf.some(prof => {
            if (prof.includes(entity)) {
                console.log(`Entity recognized as ${prof}`)
                entity = prof; return true
            }
        }); return `?teacher=${entity.trim().replaceAll(" ", "%20")}`
    }
}


function fetchData(entity, url) {
    console.log("Feching data from API...");
    var xhttp = new XMLHttpRequest()
    xhttp.onreadystatechange = () => {
        if (xhttp.readyState == 4 && xhttp.status == 200) {
            localStorage.setItem(entity, [new Date().getTime(), xhttp.responseText])
            displayDataTables(localStorage.getItem(entity), url)
        }
    }
    xhttp.open("GET", url, true)
    xhttp.send()
}


function displayDataTables(data, dataType) {
    console.log("Generating tables...")
    if (data.length == 0) {
        alert("Campo di ricerca vuoto, inserire classe aula o professore.")
        return
    } else if (data.includes("[]")) {
        alert("Entità non trovata, ricontrollare la correttezza dell'input fornito. In caso di professore inserire nome completo.")
        return
    }
    const box = document.getElementById("output-box");
    const weekDays = ["", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì"]
    data = JSON.parse(data.slice(14))
    box.innerHTML = "";

    for (let i = 1; i < 6; i++) {
        let dayTable = document.createElement('table')
        let hrs = Array.from(data.filter(record => record.giorno == i))
        let header = document.createElement('th')

        header.textContent = weekDays[i]
        dayTable.appendChild(header)
        createDayTable(hrs, dayTable, dataType)
        box.classList.remove("centred")
        box.classList.add("not-centred")
        box.appendChild(dayTable)
    }
    console.log("------------------END-QUERY------------------")
}

function createDayTable(hrs, dayTable, dataType) {
    let range = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    for (let hr in range) {
        let lesson = Array.from(hrs.filter(record => record.ora - 1 == hr))
        if (lesson.length > 0) {
            let rowLesson = document.createElement('tr')
            let cellLesson = document.createElement('td')
            if (dataType.includes("class")) {
                lesson.forEach(lsn => {
                    cellLesson.innerHTML += `<p>${JSON.stringify(lsn.prof).slice(1, -2)}</p>`
                }); cellLesson.innerHTML += `<p>${lesson[0].ora} | ${lesson[0].materia} ${lesson[0].aula}</p>`
            }
            else if(dataType.includes("teacher")) {
                if (!lesson[0].materia.includes("RIC") && !lesson[0].materia.includes("D1")) {
                    if (lesson[0].ora < 3)
                        ora = lesson[0].ora
                    else if (3 < lesson[0].ora < 6)
                        ora = lesson[0].ora - 1
                    else if (6 < lesson[0].ora <= 9)
                        ora = lesson[0].ora - 2
                    cellLesson.innerHTML += `<p>${ora} | ${lesson[0].materia} ${lesson[0].aula} | ${lesson[0].classe}</p>`
                } else continue
            }
            else {
                lesson.forEach(lsn => {
                    cellLesson.innerHTML += `<p>${JSON.stringify(lsn.prof).slice(1, -2)}</p>`
                }); cellLesson.innerHTML += `<p>${lesson[0].ora} | ${lesson[0].materia} ${lesson[0].classe}</p>`
            }
            rowLesson.appendChild(cellLesson)
            dayTable.appendChild(rowLesson)
        }
    }
}

function setEnterAction() {
    console.log("Enter action added");
    var input = document.getElementById("entity");
    input.addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
            event.preventDefault();
            document.getElementById("submit").click();
        }
    });
}

/*
#########
# TO DO #
#########

- Ricerca prof per nome o cognome (??magari tendina dinamica??)

*/