/**
 * Class Shape.
 * 
 * @class Shape
 */

export default class Mirror{
    constructor(layout, width, cells, start, end){
        this.layout = layout;
        this.width = width - 1;
        this.cells = cells;
        this.start = start;
        this.end = end;

    }

    draw(){

        let boxes = document.getElementsByClassName("shape-container");

        // HORIZONTAL MIRRORS
        if (this.layout == "horizontal"){

            for(let i = this.start; i < this.end; i++){
                boxes[i].setAttribute(
                    "class",
                    "shape-container horizontal-mirror"
                );
            }


        // VERTICAL MIRRORS
        } else if (this.layout == "vertical") {

            for(let i = this.start; i < this.end; i += this.width){

                if (i % (this.cells / this.width) != 0){

                    // if exists doesn't override horizzontal mirrors
                    if (boxes[i].classList.contains("horizontal-mirror")){
 
                        boxes[i].setAttribute(
                            "class",
                            "shape-container " +
                            "vertical-mirror " +
                            "horizontal-mirror"
                        );

                    } else {

                        boxes[i].setAttribute(
                            "class",
                            "shape-container " +
                            "vertical-mirror "
                        );
                    }
                }
            }
        }
    }
}

