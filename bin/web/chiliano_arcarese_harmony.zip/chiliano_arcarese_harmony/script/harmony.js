/**
 * Module harmony.
 * 
 * @module harmony
 */


import * as levels from "./levels.js";


window.addEventListener('load', harmony);


function harmony(){

    let container = document.getElementById("container");

    levels.level1(container)
        .then((clear0) => {
            if (clear0)
                levels.level2(container)
                    .then((clear1) => {
                        if (clear1)
                            levels.level3(container)
                                .then((clear2) => {
                                    if (clear2)
                                        alert("GAME COMPLETED")
                                })
                })
        })
        .catch(e => {
            console.log(e);
        });
}


