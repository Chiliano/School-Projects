/**
 * Class Shape.
 * 
 * @class Shape
 */

 export default class Shape{

    constructor(color, shapeType, state, grid, i, j){
        this.sprite = document.createElement("div");
        this.div = document.createElement("div");
        this.color = color;
        this.shapeType = shapeType;
        this.state = state;
        this.setValues(grid, i, j);
    }

    setValues(grid, i, j){
        this.sprite.setAttribute(
            "class", 
            "black " +
            `${this.shapeType}`
        );
        this.div.setAttribute(
            "class",
            "shape-container"
        )
        this.sprite.addEventListener(
            "click", () => {
                if (this.state){
                    this.state = false;
                    grid[i][0][j] = false;
                    this.sprite.setAttribute(
                        "class", 
                        "black " +
                        `${this.shapeType}`
                    )
                } else {
                    this.state = true;
                    grid[i][0][j] = true;
                    this.sprite.setAttribute(
                        "class", 
                        `${this.color} ` +
                        `${this.shapeType}`
                    )
                }
            }
        );
    }

    draw(){
        if (this.state){
            this.sprite.setAttribute(
                "class", 
                `${this.color} ` +
                `${this.shapeType}`
            );
        }
        this.div.appendChild(this.sprite);
        return this.div;
    }
}
