/**
 * Module levels.
 * 
 * @module levels
 */


import Shape from "./Shape.js";
import Mirror from "./Mirror.js";
import * as utility from "./utility.js";


let gridCells = [16, 20, 20, 25, 30, 30, 36, 49, 56, 64, 72];
let gridWidth =  [5 , 5 , 6 , 6 , 6 , 7 , 7 , 8 , 8 , 10, 10];


export function level1(container) {
    return new Promise((resolve, reject) => {

        // Sets of shape and colors
        let colors = ["red", "orange", "blue", "green", "yellow"];
        let types = ["square", "circle"];

        // Select a random type of shape and a random color
        let shapeType = types[Math.floor(Math.random() * types.length)];
        let color = colors[Math.floor(Math.random() * colors.length)];

        // Set number of cells and grid's shape
        let cells = gridCells[0];
        let width = gridWidth[0];

        /** Create mirrors @see Mirror.js */
        let mirror1 = new Mirror("horizontal", width, cells, 4, 8);
        let mirror2 = new Mirror("vertical", width, cells, 1, 14);

        // Create grid
        let grid = utility.createGrid(cells, width);
        utility.sizeGrid(width);
        grid[0][0][0] = true;

        // Create boolean mask
        let booleanMask = utility.createGrid(cells, width);
        utility.setBooleanMaskLvl1(booleanMask);

        utility.setBackground(color);


        /** Add shapes to container @see Shape.js */
        for (let i = 0; i < grid.length; i++) {
            for (let j = 0; j < grid[0][0].length; j++) {

                    let shape = new Shape(color, shapeType, grid[i][0][j], grid, i, j);
                    container.appendChild(shape.draw());
            }
        }

        /** Add mirrors to screen @see Mirror.js */
        mirror1.draw();
        mirror2.draw();


        /** Add victory check @event click */
        container.addEventListener("click", function activate() {
            let check = true;

            for (let i = 0; i < grid.length; i++) {
                for (let j = 0; j < grid[0][0].length; j++) {

                        if (grid[i][0][j] != booleanMask[i][0][j])
                            check = false;
                }
            }

            if (check) {
                console.log("DONE");
                container.removeEventListener("click", activate)
                setTimeout(() => {
                    container.innerHTML = "";
                    resolve(true);
                }, 300)
            }
        });
    });
}


export function level2(container) {
    return new Promise((resolve, reject) => {

        // Sets of shape and colors
        let colors = ["red", "orange", "blue", "green", "yellow"];
        let types = ["square", "circle"];

        // Select a random type of shape and a random color
        let shapeType = types[Math.floor(Math.random() * types.length)];
        let color = colors[Math.floor(Math.random() * colors.length)];

        // Set number of cells and grid's shape
        let cells = gridCells[6];
        let width = gridWidth[6];

        /** Create mirrors @see Mirror.js */
        let mirror1 = new Mirror("vertical", width, cells, 2, 33);

        // Create grid
        let grid = utility.createGrid(cells, width);
        utility.sizeGrid(width);
        console.log(grid);
        grid[0][0][1] = true;
        grid[1][0][4] = true;
        grid[4][0][0] = true;
        grid[5][0][2] = true;
        grid[5][0][4] = true;

        // Create boolean mask
        let booleanMask = utility.createGrid(cells, width);
        utility.setBooleanMaskLvl2(booleanMask);

        utility.setBackground(color);


        /** Add shapes to container @see Shape.js */
        for (let i = 0; i < grid.length; i++) {
            for (let j = 0; j < grid[0][0].length; j++) {

                    let shape = new Shape(color, shapeType, grid[i][0][j], grid, i, j);
                    container.appendChild(shape.draw());
            }
        }

        /** Add mirrors to screen @see Mirror.js */
        mirror1.draw();



        /** Add victory check @event click */
        container.addEventListener("click", function activate() {
            let check = true;

            for (let i = 0; i < grid.length; i++) {
                for (let j = 0; j < grid[0][0].length; j++) {

                        if (grid[i][0][j] != booleanMask[i][0][j])
                            check = false;
                }
            }

            if (check) {
                console.log("DONE");
                container.removeEventListener("click", activate)
                setTimeout(() => {
                    container.innerHTML = "";
                    resolve(true);
                }, 300)
            }
        });
    });
}


export function level3(container) {
    return new Promise((resolve, reject) => {

        // Sets of shape and colors
        let colors = ["red", "orange", "blue", "green", "yellow"];
        let types = ["square", "circle"];

        // Select a random type of shape and a random color
        let shapeType = types[Math.floor(Math.random() * types.length)];
        let color = colors[Math.floor(Math.random() * colors.length)];

        // Set number of cells and grid's shape
        let cells = gridCells[10];
        let width = gridWidth[10];

        /** Create mirrors @see Mirror.js */
        let mirror1 = new Mirror("horizontal", width, cells, 16, 17);
        let mirror2 = new Mirror("horizontal", width, cells, 23, 24);
        let mirror3 = new Mirror("horizontal", width, cells, 40, 41);
        let mirror4 = new Mirror("horizontal", width, cells, 47, 48);
        let mirror5 = new Mirror("horizontal", width, cells, 19, 21);
        let mirror6 = new Mirror("horizontal", width, cells, 43, 45);
        let mirror7 = new Mirror("horizontal", width, cells, 9, 11);
        let mirror8 = new Mirror("horizontal", width, cells, 13, 15);
        let mirror9 = new Mirror("horizontal", width, cells, 49, 51);
        let mirror10 = new Mirror("horizontal", width, cells, 53, 55);

        // Create grid
        let grid = utility.createGrid(cells, width);
        utility.sizeGrid(width);
        grid[0][0][1] = true;
        grid[0][0][6] = true;
        grid[1][0][3] = true;
        grid[1][0][7] = true;
        grid[3][0][2] = true;
        grid[3][0][5] = true;
        grid[5][0][5] = true;
        grid[5][0][2] = true;
        grid[7][0][4] = true;
        grid[7][0][0] = true;
        grid[8][0][1] = true;
        grid[8][0][6] = true;


        // Create boolean mask
        let booleanMask = utility.createGrid(cells, width);
        utility.setBooleanMaskLvl3(booleanMask);

        utility.setBackground(color);


        /** Add shapes to container @see Shape.js */
        for (let i = 0; i < grid.length; i++) {
            for (let j = 0; j < grid[0][0].length; j++) {

                    let shape = new Shape(color, shapeType, grid[i][0][j], grid, i, j);
                    container.appendChild(shape.draw());
            }
        }

        /** Add mirrors to screen @see Mirror.js */
        mirror1.draw();
        mirror2.draw();
        mirror3.draw();
        mirror4.draw();
        mirror5.draw();
        mirror6.draw();
        mirror7.draw();
        mirror8.draw();
        mirror9.draw();
        mirror10.draw();


        /** Add victory check @event click */
        container.addEventListener("click", function activate() {
            let check = true;

            for (let i = 0; i < grid.length; i++) {
                for (let j = 0; j < grid[0][0].length; j++) {

                    if (grid[i][0][j] != booleanMask[i][0][j])
                        check = false;
    
                }
            }


            if (check) {
                console.log("DONE");
                container.removeEventListener("click", activate)
                setTimeout(() => {
                    container.innerHTML = "";
                    resolve(true);
                }, 300)
            }
        });
    });
}