/**
 * Module utility.
 * 
 * @module utility
 */


export function createGrid(cells, width){
    let row = cells / (width - 1)
    let grid = [];
    let colums;
    for (let i = 0; i < width - 1; i++){
        colums = [];
        for (let j = 0; j < row; j++){
            colums.push(false);
        }
        grid.push([colums]);
    }
    return grid;
}


export function sizeGrid(width){
    let container = document.getElementById("container");
    container.style.width = `${width * (7.5 + 0.6) - 0.6}vh`;
}


export function clearGrid(grid){

    for (let i = 0; i < grid.length; i++) {
        for (let j = 0; j < grid[0][0].length; j++) {

            grid[i][0][j] == false;

        }
    }
    return true
}


export function setBooleanMaskLvl1(booleanMask) {
    booleanMask[0][0][0] = true;
    booleanMask[0][0][3] = true;
    booleanMask[3][0][0] = true;
    booleanMask[3][0][3] = true;
    console.log(booleanMask);
}

export function setBooleanMaskLvl2(booleanMask) {
    for (let i = 0; i < booleanMask.length; i++) {
        for (let j = 0; j < booleanMask[0][0].length; j++) {

            if ((i == 0 || i == 1) && (j == 1 || j == 4)) {
                booleanMask[i][0][j] = true;
            } else if ((i == 4) && (j == 0 || j == 5)){
                booleanMask[i][0][j] = true;
            } else if ((i == 5) && (j > 0 && j < 5)){
                booleanMask[i][0][j] = true;
            }
        }
    }
}

export function setBooleanMaskLvl3(booleanMask) {
    for (let i = 0; i < booleanMask.length; i++) {
        for (let j = 0; j < booleanMask[0][0].length; j++) {

            if ((i == 0 || i == 3 || i == 5 || i == 8) && (j > 0 && j < 3) || (j > 4 && j < 7)) {
                booleanMask[i][0][j] = true;
            } else if ((i == 1 || i == 4 || i == 7) && (j == 0 || (j > 2 && j < 5) || j == 7)){
                booleanMask[i][0][j] = true;
            }
        }
    }

    for (let i = 0; i < booleanMask.length; i++) {
        for (let j = 0; j < booleanMask[0][0].length; j++) {

            if ((i == 1 || i == 2 || i == 4 || i == 6 || i == 7) && (j == 5 || j == 6))
                booleanMask[i][0][j] = true;
            }
        }
    /*
    booleanMask[1][0][5] = false;
    booleanMask[1][0][6] = false;
    booleanMask[2][0][5] = false;
    booleanMask[2][0][6] = false;
    booleanMask[4][0][5] = false;
    booleanMask[4][0][6] = false;
    booleanMask[6][0][5] = false;
    booleanMask[6][0][6] = false;
    booleanMask[7][0][5] = false;
    booleanMask[7][0][6] = false;
    */
    console.log(booleanMask);
}


export function setBackground(randomColor){

    switch (randomColor){

        case "red":
            document.body.style.background = (
                "rgba(255, 0, 0, 0.64) url('./img/red.svg') no-repeat bottom"
            ); return true;

        case "orange":
            document.body.style.background = (
                "rgba(255, 93, 0, 0.64) url('./img/orange.svg') no-repeat bottom"
            ); return true;

        case "blue":
            document.body.style.background = (
                "rgba(7, 0, 125, 0.64) url('./img/blue.svg') no-repeat bottom"
            ); return true;

        case "green":
            document.body.style.background = (
                "rgba(31, 166, 34, 0.64) url('./img/green.svg') no-repeat bottom"
            ); return true;

        case "yellow":
            document.body.style.background = (
                "rgba(219, 199, 13, 0.64) url('./img/yellow.svg') no-repeat bottom"
            ); return true;

        default:
            return false;
    }
}