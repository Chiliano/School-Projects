# cclean

![Platform](https://img.shields.io/badge/OS%20platform%20supported-Windows-blue?style=flat)
![Language](https://img.shields.io/badge/Language-Python-yellowgreen?style=flat)
![Testing](https://img.shields.io/badge/Test-Pass-green)
![Language](https://img.shields.io/badge/Spellcheck-Pass-green?style=flat)
![Beauty standard](https://img.shields.io/badge/Pylint-10.00-green?style=flat)

## Descrizione
Il programma crea due file csv:
- programs.csv (inventario)
- properties.csv (proprietà eseguibili)


## Requisiti
Python 3 con la libreria WMI.


## Esecuzione
Eseguire il file *cclean.py* nel pacchetto di deploy.
L'output viene stoccato nei file *programs.csv* e *properties.csv* contenuti in flussi.


## Tags
CIM, Win32, File System, Python, Version, Patching, Sicurity, Registry, Windows OS


## Author

Chiliano Arcarese
