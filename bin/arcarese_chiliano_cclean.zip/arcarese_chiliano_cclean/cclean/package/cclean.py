#!/usr/bin/env python3

"""
This script make a software inventory to trace softwares' versions.
"""

from datetime import datetime
import platform
import os
import time
from os.path import exists
import wmi
from utility import log


def analysis(prog):
    """
    Creating and storing inventory
    """

    # Create the object of the current device
    device = wmi.WMI()

    # Checking all the software on the device
    for software in device.Win32_Product():
        inventory = ""

        # Getting data
        if software.InstallLocation is not None:
            inventory = software.Name + ";" + software.InstallLocation
            inventory += ";" + software.Version
            # Open properties.csv file to store *.exe file's properties
            initializing_properties_file(software)
            # Add data to the inventory
            prog.write(device_info() + inventory + "\n")


def collect_properties(software, prop):
    """
    Getting executable files properties
    """

    # Getting all executable files per every software
    for root, dirs, files in os.walk(software.InstallLocation):
        del dirs
        for file in files:

            # Filter out all the not executable files
            file_filter = file.split(".")
            if len(file_filter) == 2:
                if ("exe" in file_filter  or "com" in file_filter):
                    # Getting executable file properties
                    out = ""
                    j = 0
                    st_ = ["ST_MODE=","ST_INO=","ST_DEV=","ST_NLINK=","ST_UID="]
                    st_ += ["ST_GID=","ST_SIZE=","ST_ATIME=","ST_MTIME=","ST_CTIME="]
                    for i in os.stat(os.path.join(root, file)):
                        out += st_[j] + str(i) + ";"
                        j+=1
                    # Storing properties
                    prop.write(device_info() + software.name + ";" + file + ";" + out + "\n")


def device_info():
    """
    Getting device info
    """

    # Getting timestamp, operating system and device's name
    info = (str(time.time()) + ";" + str(datetime.now()) + ";" +
            platform.system().lower() + ";" +
            platform.node() + ";")
    return info


def initializing_programs_file():
    """
    Open properties.csv file to store the software's inventory
    """

    # Controlling csv existance
    if not exists("../flussi/programs.csv"):
        # If doesn't exist open file in write and create heading
        with open("../flussi/programs.csv", "w", encoding="UTF-8") as prog:
            # Writing heading
            prog.write("unixtimestamp;timestamp;platform;")
            prog.write("pc_name;software;location;version\n")
            # Creating and storing inventory
            analysis(prog)

    else:
        # If exist open file in append
        with open("../flussi/programs.csv", "a", encoding="UTF-8") as prog:
            # Creating and storing inventory
            analysis(prog)


def initializing_properties_file(software):
    """
    Open properties.csv file to store *.exe file's properties
    """
    # Controlling csv existance
    if not exists("../flussi/properties.csv"):
        # If doesn't exist open file in write and create heading
        with open("../flussi/properties.csv", "w", encoding="UTF-8") as prop:
            # Writing heading
            prop.write("unixtimestamp;timestamp;platform;pc_name;software;file;")
            prop.write("ST_MODE;ST_INO;ST_DEV;ST_NLINK;ST_UID;ST_GID;ST_SIZE;")
            prop.write("ST_ATIME;ST_MTIME;ST_CTIME\n")
            # Getting executable files properties
            collect_properties(software, prop)

    else:
        # If exist open file in append
        with open("../flussi/properties.csv", "a", encoding="UTF-8") as prop:
            # Getting executable files properties
            collect_properties(software, prop)


if __name__ == "__main__":

    # Execution tracing
    log()
    # Open properties.csv file to store the software's inventory
    initializing_programs_file()
