# statsfile

![Language](https://img.shields.io/badge/Language-Python-yellowgreen?style=flat)
![Platform](https://img.shields.io/badge/OS%20Platform%20supported-Linux-blue?style=flat)
![Platform](https://img.shields.io/badge/OS%20platform%20supported-Windows-blue?style=flat)
![Testing](https://img.shields.io/badge/Test-Pass-green)
![Language](https://img.shields.io/badge/Spellcheck-Pass-green?style=flat)

## Descrizione

Il programma visualizza alcune stats del file trace.log presente nella cartella log.

## Requisiti

Python

## Esecuzione

Programma eseguibile da command line.

Spostarsi in:
        
    ../arcarese_chiliano_statsfiles/statefiles/package
    
ed eseguire il comando:

    python statsfile.py

## Tags

Sistema operativo, Piattaforma, Data, Log, Trace, File system, Proprietà file, Cross platform, Programmazione ad oggetti

## Author

Chiliano Arcarese