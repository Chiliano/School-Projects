#!/usr/bin/env python3

"""
"""

import win32com.client
from writer import Writer
from icecream import ic
from utility import start_log, end_log

if __name__ == "__main__":

    start_log()

    wmi = win32com.client.GetObject(r"winmgmts://./root/cimv2")
    group_user = wmi.ExecQuery(
        "SELECT * FROM Win32_GroupUser"
    )
    col_account = []

    for i, group in enumerate(group_user):

        group_data = group.GroupComponent.split('\\')[-1].split('"')
        domain = group_data[1]
        group_name = group_data[3]

        account_data = group.PartComponent.split('\\')[-1].split('"')
        account = account_data[-2]

        col_account.append({
            "domain": domain,
            "group": group_name,
            "account": account
        })

    writer = Writer()
    writer.write("../flussi/groupuser.csv", col_account)
    writer.write("../flussi/groupuser.xml", col_account)

    end_log()