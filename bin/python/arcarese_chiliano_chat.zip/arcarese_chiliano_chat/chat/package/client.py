"""
## Chat group client.

This module contains the `class Client`.
The client enstablish the connection with the server in order
to provide a gruop chat among the connected user.

Chat's `messagges wont be saved` anywere, this causes their loss
once the client clear his terminal.

Author
------
Chiliano Arcarese

Version
-------
4.0.0
"""


import socket
from threading import Thread, Lock
from utility import log


class Client:

    """
    `Multithread client class` that manages messages in I/O.
    Each thread is created to manage the messagges in input or in output.

    Methods
    -------
    `__init__(self, _ip_addr: str, _port: int, _username: str)` -> None
        Initialize an instance of the Client object with given parameters
    `__enter(self)` -> self
        Logs client's start
    `__exit__(self, exc_type, exc_value, traceback)` -> None
        Shuts down the client and logs it
    `refresh_chat(self)` -> None`
        Receves messages in input from the server and print them to the terminal
    `send_message(self)` -> None
        Sends messages to the server and visualize them to the terminal

    See also
    --------
    `socket` : module
        Built in module for sockets' creation and managment
    `threading` : module
        Built in module for threads' creation and managment
    `utility` : module
        Author module for logging and other utilities
    """


    def __init__(self, _ip_addr: str, _port: int, _username: str) -> None:
        """
        Initialize an instance of the Client object with given parameters.

        Parameters
        ----------
        `_ip_addr` : str
            Server's IP address
        `_port` : int
            Port number where the server listens on
        `_username` : str
            Username used by this client

        Attributes
        ----------
        `self._socket` : socket
            Client's socket
        `self._socket_lock` : Lock
            Lock object to manage socket access from the functions
            and avoid conflicts
        `self.username` : str
            Username used by this client
        """

        self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._socket.connect((_ip_addr, _port))
        self._socket_lock = Lock()

        self.username = f"\n{_username} > "


    def __enter__(self) -> object:
        """
        Logs client's start.

        Returns
        -------
        `self`: pointer
            Pointer on this instance
        """

        log(
            "START - Socket initialized, Connection established with the server",
            r"../log/client.log",
        )
        return self


    def __exit__(self, exc_type, exc_value, traceback) -> None:
        """
        Shuts down the client and logs it.
        """
        self._socket.close()
        log("END", r"../log/client.log")


    def refresh_chat(self) -> None:
        """
        Receves messages in input from the server and print them to the terminal.

        Exceptions
        ----------
        socket.timeout : Exception
            Raised when a read operation times out because no data
            was received within timeout seconds, in this case the
            client repeat the operation and logs the timeout
        socket.error : Exception
            Raised if the client isn't authorized to be among the chat's users
            or when a generic error occourse. Logs the error

        Raises
        ------
        `socket.error` : Exception
            Raised if the client isn't authorized to be among the chat's users
        """

        max_attempts = 10
        attempts = 0

        while attempts < max_attempts:
            try:
                response = None
                self._socket.settimeout(10)
                with self._socket_lock:
                    response = self._socket.recv(1024)
                attempts = 0
                log("Message received", r"../flussi/chat.csv")
                print(response.decode())
                if "WARNING" in response:
                    raise socket.error
            except socket.timeout as timeout_error:
                log(str(timeout_error), r"../log/client.log")
                attempts += 1
            except socket.error as socket_error:
                log(str(socket_error), r"../log/client.log")


    def send_message(self) -> None:
        """
        Sends messages to the server and visualize them to the terminal.

        Exceptions
        ----------
        socket.error : Exception
            Raised if there is an issue sending message
            through the network connection. Logs the error
        """

        while True:
            try:
                message = input(self.username)
                with self._socket_lock:
                    self._socket.send((self.username + message).encode())
                log("Message sent", r"../log/client.log")
            except socket.error as socket_error:
                log(str(socket_error), r"../log/client.log")



if __name__ == "__main__":

    with Client("192.168.1.55", 50318, "Chiliano") as chat_client:
        chat_refresher = Thread(target=chat_client.refresh_chat, daemon=False)
        message_sender = Thread(target=chat_client.send_message, daemon=False)
        chat_refresher.start()
        message_sender.start()
        chat_refresher.join()
        message_sender.join()
