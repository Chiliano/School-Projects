"""
## Chat group server.

This module contains the `class Server`.
The server manage different client connection in order
to provide a gruop chat `among` the `authorized` and connected user.

Chat's `messagges wont be saved` anywere, this causes their loss
once the client clear his terminal.

Author
------
Chiliano Arcarese

Version
-------
4.0.0
"""


import socket
from threading import Thread, Lock
from utility import log


class Server:

    """
    `Multithread server class` that manages all clients connections to the
    same host/port pair, creating dedicated threads for each connection.


    Methods
    -------
    `__init__(self, port: int)` -> None
        Initialize an instance of the Server object with given parameters
    `__enter(self)` -> self
        Logs server's start
    `__exit__(self, exc_type, exc_value, traceback)` -> None
        Shuts down the server and logs it
    `_check_port(self, port: int)` -> bool
        Check if the given port is in the valid range
    `_enstablish_connection(self, _client_connection, _client_address)` -> None
        Receve messages from a client and send them to all the connected users
    `_permission_denied(self, _client_connection, _client_address)` -> None
        Send an error message when someone tries to connect without permission
    `accept_connection(self)` -> None
        Accept the connection from client side and create new threads
        for every incoming connection

    See also
    --------
    `socket` : module
        Built in module for sockets' creation and managment
    `threading` : module
        Built in module for threads' creation and managment
    `utility` : module
        Author module for logging and other utilities
    """


    def __init__(self, port: int = None):
        """
        Initialize an instance of the Server object with given parameters.

        Parameters
        ----------
        `port` : int
            Port in which the server is hosted, default value: None

        Attributes
        ----------
        `self._socket` : socket
            Server's socket
        `self. _port` : int
            Port number taken as parameter
        `self._socket_lock` : Lock
            Lock object to manage socket access from the functions
            and avoid conflicts
        `self._connected` : list[socket]
            List of sockets connected with a client
        `self._registered_users` : dict{str: str}
            Contains authorized users
        """

        _hostname = socket.gethostname()
        _ip_address = socket.gethostbyname(_hostname)

        self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._port = self._check_port(port)
        self._socket.bind((_ip_address, self._port))
        self._socket_lock = Lock()

        self._connected = []
        self._registered_users = {"local_host": r"127.0.0.1", "this_pc": _ip_address}

        print(
            "______________",
            "GROUP CHAT",
            "______________",
            "Members:",
            self._registered_users,
            "\n",
            sep="\n",
        )


    def __enter__(self) -> object:
        """
        Logs server's start.

        Returns
        -------
        `self` : pointer
            Pointer on this instance
        """
        log("START", r"../log/server.log")
        return self


    def __exit__(self, exc_type, exc_value, traceback) -> None:
        """
        Shuts down the server and logs it.
        """
        self._socket.close()
        log("END", r"../log/server.log")


    def _check_port(self, port: int) -> bool:
        """
        Check if the given port is in the valid range

        Parameters
        ----------
        `self._port` : int
            Port number taken as parameter

        Returns
        -------
        True : bool
            If is a number between 0 and 65536
        False : bool
            If isn't a number between 0 and 65536
        """

        return port if 0 < port < 65536 else False


    def _enstablish_connection(
        self, _client_connection=None, _client_address=None
    ) -> None:
        """
        Receve messages from a client and send them to all the connected users.

        Parameters
        ----------
        `_client_connection` : socket
            Socket connected with a specific client
        `_client_address` : tuple
            Contains client's IP address and port number

        Exceptions
        ----------
        `socket.error` : Exception
            Raised if there is an issue with client connecton
            Logs the error and remove the client from the _connected list
        """

        try:
            while True:
                if data := _client_connection.recv(1024):
                    for client in self._connected:
                        if client != _client_connection:
                            with self._socket_lock:
                                client.send(data)
                    print(f"MESSAGE | New message from: {_client_address}")
        except socket.error as socket_error:
            log(str(socket_error), r"../log/server.log")
            print(f"WARNING | Connection closed with: {_client_address}")
            self._connected.remove(_client_connection)


    def _permission_denied(self, _client_connection=None, _client_address=None) -> None:
        """
        Send an error message when someone tries to connect without permission.

        Parameters
        ----------
        `_client_connection` : socket
            Socket connected with a specific client
        `_client_address` : tuple
            Contains client's IP address and port number
        """

        with _client_connection:
            _client_connection.send(
                "Permission denied. Sorry your not registred in this chat".encode(),
            )
            print(f"WARNING | Permission Denied to:\n{_client_address}")


    def accept_connection(self) -> None:
        """
        Accept the connection from client side if from an authorized user
        and create new threads for every incoming connection. If the user isn't
        authorized the server sends to him a warning.
        """

        while True:
            self._socket.listen()
            client_connection, client_address = self._socket.accept()
            if client_address[0] in self._registered_users.values():
                self._connected.append(client_connection)
                print(f"MESSAGE | Joined the chat: {client_address} ")
                client_connection.settimeout(120)
                Thread(
                    target=self._enstablish_connection,
                    args=(client_connection, client_address),
                    daemon=True,
                ).start()
            else:
                self._permission_denied(client_connection, client_address)



if __name__ == "__main__":

    with Server(port=50318) as chat_server:
        chat_server.accept_connection()
