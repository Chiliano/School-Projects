# PROCESS MANAGER 

![Testing](https://img.shields.io/badge/Test-Pass-green)
![Language](https://img.shields.io/badge/Language-Python-yellowgreen?style=flat)
![Platform](https://img.shields.io/badge/OS%20platform%20supported-Windows-blue?style=flat)
![Language](https://img.shields.io/badge/Spellcheck-√-green?style=flat)
![Schedulable](https://img.shields.io/badge/Schedulable-√-green?style=flat)

![Testing: 10/10](https://img.shields.io/badge/Pylint%20|%20Module:%20app.py-10.00-green)
![Testing: 10/10](https://img.shields.io/badge/Pylint%20|%20Module:%20process_manager.py-10.00-green)
![Testing: 10/10](https://img.shields.io/badge/Pylint%20|%20Module:%20utility.py-10.00-green)
![Testing: 9.86/10.00 | Due to code error: I1101](https://img.shields.io/badge/Pylint%20|%20Module:%20writer.py-9.86/10.00-yellow)

------

<br />
<br />

## Description
The program can ``kill`` or ``find`` a process and prints on terminal the properties.
The process are listed and stored in a csv file.

The program can list all the ``svchost.exe`` process istance and store them in another csv file too.

Properties:

+ ``pid: int``
+ ``ppid: int``
+ ``name: str``
+ ``status: str``
+ ``username: str``
+ ``create_time: int``

<br />

--------
<br />

## Requirements
- Python3
- library at: ``./requirements.txt``

<br />

--------
<br />

## Execution
Usage: ``python kill_process.py -option argument``

### Options and Arguments
- ``-kill <name-or-pid>`` :  Kills the process associated to the given identifier

- ``-find <name-or-pid>`` :  Prints on terminal the given process' properties

- ``-l`` :  Stores all the processes in a csv file and display them on terminal

### svchost.exe

+ If you ty to find ``svchost.exe`` the script will store on a csv file all istances of that process.

<br />

--------
<br />

## Example of csv record

| unix time | date | operative_system | hostname | create_time | name | pid | ppid | status | username |
|---|---|---|---|---|---|---|---|---|---|
| 1676212539.258078 |2023-02-12 15:35:39.258078 | windows | DESKTOP-SI30CC2 | 0.0 | System Idle Process | 0 | 0 | running | NT AUTHORITY\SYSTEM |

<br />
<br />

## Tags
process, kill process, process managing, python, windows

<br />

## Author
Arcarese Chiliano
