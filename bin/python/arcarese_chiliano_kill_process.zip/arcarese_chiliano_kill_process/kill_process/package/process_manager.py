#!/usr/bin/env python3

"""
Rapresents a process manager that implements
methods to find and kill a process.

Author
------
Chiliano Arcarese

Version
-------
2.5.0
"""


import psutil
from icecream import ic
from utility import log


class ProcessManager:

    """
    Rapresents a process manager that implements
    methods to ``find`` and ``kill`` a process by PID or name.

    ...

    Attributes
    ----------
    processes : list[dict]
        Collection of processes rapresented by a dictionary.


    Methods
    -------
    __init__(self) -> None:
        Inits Process_manager class.

    findProcess(self, key: str or int) -> dict or None
        Return process' dictionary in the collection processes.

    killProcess(self, key: int) -> bool or None
        Kill the selected process.


    Notes
    -----
    This class uses ``psutil`` to kill processes and to get
    processes properties and ``icecream`` for debugging and
    console messages displaying.
    """

    def __init__(self) -> None:
        """
        Inits Process_manager class.

        Attributes
        ----------
        processes : list[dict]
            Collection of processes rapresented by a dictionary.
        """

        self.processes: list = [
            process.as_dict(
                attrs=["name", "pid", "ppid", "status", "username", "create_time"]
            )
            for process in psutil.process_iter()
        ]
        ic.disable()
        ic(self.processes)

    def find_process(self, key: str or int) -> dict or None:
        """
        Return process' dictionary in the collection processes
        using key to find the process.

        Parameters
        ----------
        key : str or int
            Key to find the process. It could
            be the PID or the process' name.

        Returns
        -------
        process : dict
            The dictionary that contains the data
            of the searched process.

        Raises
        ------
        psutil.NoSuchProcess
            If the process doesn't exists the program
            raises a psutil.NoSuchProcess error.
            The error is handled in kill_process.py.
        """

        ic.enable()
        if isinstance(key, int):
            for process in self.processes:
                if process["pid"] == key:
                    ic.configureOutput(prefix="found| -> ")
                    ic(process)
                    log(f"Process found: [{process['name']}, {process['pid']}]")
                    return process
            raise psutil.NoSuchProcess(key, None, "wrong process identifier")

        if isinstance(key, str):
            if key != "svchost.exe":
                for process in self.processes:
                    if process["name"] == key:
                        ic.configureOutput(prefix="found| -> ")
                        ic(process)
                        log(f"Process found: [{process['name']}, {process['pid']}]")
                        return process
                raise psutil.NoSuchProcess(None, key, "wrong process identifier")
            return self.find_services()

        return None

    def kill_process(self, key: int) -> bool or None:
        """
        Kills a process using a key <pid-or-name> and returns
        the process' dictionary in the processes collection.

        Parameters
        ----------
        key : str or int
            Key to kill the process. It could
            be the PID or the process' name.

        Returns
        -------
        process : dict
            The dictionary that contains the data
            of the killed process.

        Raises
        ------
        psutil.NoSuchProcess
            If the process doesn't exists the program
            raises psutil.NoSuchProcess error.
            The error is handled in kill_process.py.
        """

        ic.enable()
        if isinstance(key, int):
            for process in self.processes:
                if process["pid"] == key:
                    print(f"\nKilling {key}...")
                    psutil.Process(key).kill()
                    ic.configureOutput(prefix="killed| -> ")
                    ic(process)
                    log(f"Process killed: [{process['name']}, {process['pid']}]")
                    return True
            raise psutil.NoSuchProcess(key, None, "wrong process identifier")

        if isinstance(key, str):
            for process in self.processes:
                if process["name"] == key:
                    print(f"\nKilling {key}...")
                    psutil.Process(process["pid"]).kill()
                    ic.configureOutput(prefix="killed| -> ")
                    ic(process)
                    log(f"Process killed: [{process['name']}, {process['pid']}]")
                    return True
            raise psutil.NoSuchProcess(None, key, "wrong process identifier")

        return None

    def find_services(self) -> list[dict]:
        """
        Return all svchost.exe's processes.

        Returns
        -------
         : list[dict]
            All svchost.exe's active
            processes (windows services).
        """

        for process in self.processes:
            if process["name"] == "services.exe":
                service_exe = psutil.Process(process["pid"])
                children = service_exe.children(recursive=True)
                return [
                    child.as_dict(
                        attrs=[
                            "pid",
                            "ppid",
                            "name",
                            "status",
                            "username",
                            "create_time",
                        ]
                    )
                    for child in children
                    if child.name() == "svchost.exe"
                ]
        return None
