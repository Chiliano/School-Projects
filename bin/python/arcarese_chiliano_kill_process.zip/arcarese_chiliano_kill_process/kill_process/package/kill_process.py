#!/usr/bin/env python3

"""
The program can kill a process and print on terminal the properties.
The processes are listed and stored in a csv file.

Properties:

+ ``ppid: int``
+ ``pid: int``
+ ``name: str``
+ ``status: str``
+ ``username: str``
+ ``creation_time: int``

Author
------
Chiliano Arcarese

Version
-------
2.5.0
"""


from typing import Callable
from sys import argv, platform
from psutil import NoSuchProcess
from icecream import ic
from process_manager import ProcessManager
from writer import writer
from utility import log, NotSupportedPlatform


def command_check(
    command: str = "", option: str = "", argument: str = ""
) -> list[dict] or None:
    """
    Checks the command options syntax to
    execute the associated operation.

    Parameters
    ----------
    option : str
        CLI Option of this program.
        Possible options:
        `-help`, `-kill`, `-find`, `-l`
    argument : str
        Argument written on CLI.

    Returns
    -------
    process_manager.processes : list[dict]
        The list of dictionaries that contains
        all the processes recorded by psutil

    Catches
    -------
    ValueError
        If the type of the method ``kill_process()``
        or ``find_processes()`` doesn't match the required one.
    NoSuchProcess
        Raised by the methods ``kill_process()`` or ``find_processes()``
        when process doesn't exist.

    See Also
    --------
    process_manager : class
        The class that contains the methods to manage processes:
        + kill_process()
        + find_processes()
    """

    if option:
        if option == "-help":
            print(
                f"Usage: python {command} -find <pid-or-name> | -kill <pid-or-name>\n",
                "  -kill  <pid-or-name>  Kills the process with the given pid",
                "  -find  <pid-or-name>  Prints on terminal the given process properties.",
                "  -find  svchost.exe    Strores on a csv all svchost's instance proprieties.",
                "  -l                    Lists processes in a csv file and display them",
                "[-kill, -find, -l] -> Store on a csv all device's processes",
                sep="\n",
            )
            log("Help message dysplaied")
            return None

        if option == "-kill" and argument:
            process_manager = ProcessManager()
            return None, on_process_operation(
                process_manager,
                (process_manager.kill_process, argument),
                (process_manager.kill_process, argument),
            )

        if option == "-find" and argument:
            process_manager = ProcessManager()
            return (
                on_process_operation(
                    process_manager,
                    (process_manager.find_process, argument),
                    (process_manager.find_process, argument),
                ),
                process_manager.processes,
            )

        if option == "-l":
            process_manager = ProcessManager()
            show_processes(process_manager.processes)
            log("Processes listed")
            return None, process_manager.processes

    else:
        print(f"See extra features: python3 {command} [-help]")
        log("Error: unknown option")

    return None


def on_process_operation(
    manager: ProcessManager,
    name_operation: list[Callable, str or int],
    pid_operation: list[Callable, str or int],
) -> list[dict] or None:
    """
    Executes the given operation on the selected process.

    Parameters
    ----------
    manager: ProcessManager
        Process manager object to access
        processes list and operation.
    name_operation: list
        List of the processes names and operation to execute.
    pid_operation: list
        List of the processes PIDs and operation to execute.

    Returns
    -------
    process_manager.processes : list[dict]
        The list of dictionaries that contains
        all the processes recorded by psutil.

    Catches
    -------
    ValueError
        If the type of the method ``kill_process()``
        or ``find_processes()`` doesn't match the required one.
    NoSuchProcess
        Raised by the methods ``kill_process()`` or ``find_processes()``
        when process doesn't exist.

    See Also
    --------
    process_manager : class
        The class that contains the methods to manage processes:
        + kill_process()
        + find_processes()
    """

    try:
        pid_operation[0](int(pid_operation[1]))
        return manager.processes

    except ValueError:
        try:
            if name_operation[1] != "svchost.exe":
                name_operation[0](name_operation[1])
            else:
                return name_operation[0](name_operation[1])
        except NoSuchProcess as exception:
            print(f"psutil.NoSuchProcess: {exception}")
            log(f"Error: {exception}")

    except NoSuchProcess as exception:
        print(f"psutil.NoSuchProcess: {exception}")
        log(f"Error: {exception}")
    return None


def show_processes(processes: list[dict]) -> None:
    """
    Shows the processes in the list on the terminal.
    Requires the user's input every 30 processes to continue.

    Parameters
    ----------
    processes : list[dict]
        The list of dictionaries that contains
        all the processes recorded by psutil.
    """

    ic.enable()
    ic.configureOutput(prefix="found| -> ")
    output: str = ""
    for i, process in enumerate(processes):
        output += (
            f"{process['create_time']} | "
            + f"{process['name']} | "
            + f"{process['pid']} | "
            + f"{process['ppid']} | "
            + f"{process['status']} | "
            + f"{process['username']}\n"
        )
        if (i % 30 == 0 and i != 0) or i == len(processes) - 1:
            print(output)
            input("Press to continue...")
            output = ""
    print()


if __name__ == "__main__":
    if platform == "win32":
        log("START")

        try:
            svchost_list, process_list = command_check(
                command=argv[0], option=argv[1], argument=argv[2]
            )
            if process_list and svchost_list:
                writer(r"../flussi/process.csv", process_list)
                print("\nProcesses listed. Check the file: <../flussi/process.csv>\n")
                writer(r"../flussi/svchost.csv", svchost_list)
                print("\nProcesses listed. Check the file: <../flussi/svchost.csv>\n")
                log("Processes and svchost listed. Check: <../flussi/*.csv>")
            elif process_list:
                writer(r"../flussi/process.csv", process_list)
                print("\nProcesses listed. Check the file: <../flussi/process.csv>\n")

        except IndexError:
            try:
                if process_list := command_check(command=argv[0], option=argv[1]):
                    writer(r"../flussi/process.csv", process_list)
                    print(
                        "\nProcesses listed. Check the file: <../flussi/process.csv>\n"
                    )
            except IndexError:
                process_list = command_check(command=argv[0])
        except KeyboardInterrupt:
            log("KeyboardInterrupt: win error 0xc000013A")

        log("END")

    else:
        log("START")
        log("Error: Tryng to exec in unsupported OS")
        log("END")
        raise NotSupportedPlatform("This software can be executed only on Win32 OS")
