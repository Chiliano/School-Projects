#!/usr/bin/env python3

"""
This writer supports 3 data formats: csv, xml, json
(json not implemented yet)

Author
------
Chiliano Arcarese

Version
-------
3.5.0
"""

import platform
import time
from datetime import datetime
from os.path import exists
from lxml import etree as xml
from icecream import ic
from colorama import Fore, Style
from utility import progress_bar


def writer(file_path: str, col_item: list[dict]) -> None:
    """
    Write the given content in a formatted file.

    Parameters
    ----------
    file_path : str
        File's path. Absolute or relative path for file's allocation.
    col_item :  list[dict]
        Collection of items. Each record rapresents an object.

    Raises
    ------
    NotImplementedError
        Json format not implemented yet.
    """

    file_format = file_path.split(".")[-1]

    if file_format == "csv":
        header, content = to_csv(col_item)
        if exists(file_path):
            with open(file_path, "a", encoding="UTF-8") as csv:
                csv.write(content)
            print(Style.RESET_ALL)
            return None

        with open(file_path, "a", encoding="UTF-8") as csv:
            csv.write(header + "\n" + content)
        print(Style.RESET_ALL)
        return None

    if file_format == "xml":
        content = to_xml(col_item)
        xml.indent(content, space="\t", level=0)
        content.write(file_path, encoding="utf-8", xml_declaration=True)
        print(Style.RESET_ALL)
        return None

    if file_format == "json":
        print(Style.RESET_ALL)
        raise NotImplementedError("Json format not implemented yet")

    ic("Error: Unknown format")
    return None


def to_csv(col_item: list[dict]) -> str and str:
    """
    Formats the content of the csv file.

    Parameters
    ----------
    col_item : list[dict]
        Collection of items. Each item is a row in the file.

    Returns
    -------
    header : str
        File's header. Contains all the file's columns. These are items' properties.
    content : str
        File's content. Contains all the file's rows, header excluded
    """

    keys = sorted(col_item[0])
    header = "unix_time;date;operative_system;hostname;" + ";".join(keys)
    device_info = (
        f"{str(time.time())};{str(datetime.now())};"
        + f"{platform.system().lower()};{platform.node()};"
    )
    content = ""

    for i, item in enumerate(col_item):
        content += f"{device_info}"
        for key in keys:
            content += f"{item[key]};"
        content += "\n"
        progress_bar(i + 1, len(col_item), "csv ", Fore.YELLOW)
    return header, content


def to_xml(col_item: list[dict]) -> xml:
    """
    Formats the content of the xml file.

    Parameters
    ----------
    col_item : list[dict]
        Collection of items. Each tag item is an item in the file.

    Returns
    -------
    tree : xml
        File's content. Each tag item is an item from col_item.
    """

    keys = col_item[0].keys()

    root = xml.Element("root")
    css = xml.ProcessingInstruction(
        "xml-stylesheet", text='type="text/css" href="style.css"'
    )
    root.addprevious(css)

    for i, item in enumerate(col_item):
        element = xml.SubElement(root, "item")
        unix_time = xml.SubElement(element, "unix_time")
        unix_time.text = str(time.time())
        date = xml.SubElement(element, "date")
        date.text = str(datetime.now())
        os = xml.SubElement(element, "operative_system")
        os.text = platform.system().lower()
        hostname = xml.SubElement(element, "hostname")
        hostname.text = platform.node()
        for key in keys:
            item_property = xml.SubElement(element, key)
            item_property.text = str(item[key])

            tree = xml.ElementTree(root)

        progress_bar(i + 1, len(col_item), "xml ", Fore.YELLOW)

    return tree


if __name__ == "__main__":
    items = [
        {"height": "100px", "width": "100px"},
        {"height": "150px", "width": "150px"},
        {"height": "200px", "width": "200px"},
    ]

    writer(r"../flussi/writer_test.csv", items)
    writer(r"../flussi/writer_test.xml", items)
    writer(r"../flussi/writer_test.json", items)
