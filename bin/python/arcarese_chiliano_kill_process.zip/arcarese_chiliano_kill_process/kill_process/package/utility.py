#!/usr/bin/env python3

"""
Utility module. Contains some usefull functions and classes.

Author
------
Chiliano Arcarese

Version
-------
3.5.0
"""


import platform
import time
import types
from datetime import datetime
from functools import wraps
from time import perf_counter
from icecream import ic
from colorama import Fore


class NotSupportedPlatform(Exception):

    """
    Exception for executions on not
    supported operative systems.

    Attributes
    ----------
    platform : string
        Device's operative system.

    Methods
    -------
    __init__(self, platform=platform.system().lower():str, *args: tuple) -> None
        Inits the exception NotSupportedPlatform.

    __str__(self) -> str
        Return an excepyion message.

    See Also
    --------
    platform: module
        Module to get some system info.
    """

    def __init__(
        self, *args: tuple, device_os: str = platform.system().lower()
    ) -> None:
        """
        Inits the exception notSupportedPlatform.

        Attributes
        ----------
        device_os : string
            Device's operative system.

        Parameters
        ----------
        device_os : str
            Device's operative system.
            Default: platform.system().lower()
        args : tuple
            Others parameters packed in a tuple.
            Usable for the exeption message.
        """

        super().__init__(args)
        self.device_os = device_os

    def __str__(self) -> str:
        """
        Return a description of the raised problem.

        Returns
        -------
         : str
            A description of the raised problem.
        """

        return f"This software can't be executed on {self.device_os} OS"


def memoize(func):
    """
    Developer annotation: To study.

    Add a cache to optimize recursive function.
    """
    cache = {}

    @wraps(func)
    def wrapper(*args, **kwargs):
        key = str(args) + str(kwargs)

        if key not in cache:
            cache[key] = func(*args, **kwargs)

        return cache[key]

    return wrapper


def get_time(func: types.FunctionType) -> types.FunctionType:
    """
    Times the function given as parameter.

    Parameters
    ----------
    func : function
        Function to execute and time.

    See Also
    --------
    types : module
        Define names for built-in types that
        aren't directly accessible as a builtin.
        Used for type hint.
    functools : module
        Tools for working with functions and callable
        objects. Used `wraps` for decorator
    """

    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = perf_counter()
        func(*args, **kwargs)
        end_time = perf_counter()
        total_time = round(end_time - start_time, 6)

        return total_time

    return wrapper


@get_time
def log(msg: str) -> None:
    """
    Write a line in the log file of the calling module.

    Parameters
    ----------
    msg : str
        Message to write at the end of the line

    Decorator
    ---------

    See Also
    --------
    platform: module
        Module to get some system info. This function uses
        `platform.system()` to get the OS and `platform.node()`
        to get device's name.
    datetime: module
        Module to get anf format timestamps. This function uses
        `datetime.now()` to get the timestamp on runtime in Unix
        timestamp format.
    """

    with open("../log/trace.log", "a", encoding="UTF-8") as trace:
        trace.write(
            f"{str(time.time())};{str(datetime.now())};"
            + f"{platform.system().lower()};{platform.node()}"
            + f";{msg}\n"
        )


def progress_bar(progress: int, total: int, msg: str, color: Fore) -> None:
    """
    Progress bar in the terminal.
    Usable in for loops.

    Parameters
    ----------
    progress : int
        Current iterating variable like the classic i.
    total : int
        Total tumber of iteration.
    message : string
        Message to display afte the word loading.
    color : class
        Color of the progress bar in the terminal while loading.

    See Also
    --------
    Fore : str
        Variable from module `colorama`, used to color terminal's prompt
    """

    if progress == 1:
        print(f"{color}Loading {msg}")
    percent = 100 * (progress / float(total))
    load_bar = "■" * int(percent) + "-" * (100 - int(percent))
    print(f"{color}\r |{load_bar}|{percent:.2f}%", end="\r")
    if progress == total:
        print(f"{Fore.GREEN}\r|{load_bar}| {percent:.2f}%", end="\r")
        print(end="\n")


if __name__ == "__main__":
    ic.enable()
    ic.configureOutput(includeContext=True)
    ic(f"Time: {get_time(log)} s")
    ic(f"Time: {log('END')} s")
    ic(type(progress_bar))

    for i in range(100):
        progress_bar(i, 99, "bar...", Fore.GREEN)
