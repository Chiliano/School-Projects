# CCLEAN

![Language](https://img.shields.io/badge/Language-Python-yellowgreen?style=flat)
![Platform](https://img.shields.io/badge/OS%20platform%20supported-Windows-blue?style=flat)
![Platform](https://img.shields.io/badge/OS%20platform%20supported-Linux-blue?style=flat)
![Testing](https://img.shields.io/badge/Test-Pass-green)
![Testing](https://img.shields.io/badge/Pylint-10.00-green)
![Language](https://img.shields.io/badge/Spellcheck-Pass-green?style=flat)

## Descrizione


## Requisiti



## Esecuzione



## Anteprima Esecuzione



## Tags


## Author
Lepre Leida, Arcarese Chiliano
