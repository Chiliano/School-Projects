#!/usr/bin/env python3

"""

"""


import win32evtlog
import win32security
from colorama import Style, Fore
from writer import Writer
from utility import start_log, end_log, progress_bar


def get_event_info() -> list[dict]:

    """
    """

    logtype = "%SystemRoot%\System32\Winevt\Logs\Security.evtx"
    hand = win32evtlog.OpenEventLog("localhost", logtype)
    flags =  win32evtlog.EVENTLOG_SEQUENTIAL_READ|win32evtlog.EVENTLOG_FORWARDS_READ
    total = win32evtlog.GetNumberOfEventLogRecords(hand)
    events_info = []

    for i in range(total):
        events = win32evtlog.ReadEventLog(hand, flags, 0)
        if events:
            for event in events:
                if event.Sid is not None:
                    domain, user, _ = win32security.LookupAccountSid(None, event.Sid)
                    events_info.append({
                        "event_id": event.EventID,
                        "sid": f"{domain}/{user}",
                        "event_type": event.EventType,
                        "event_category": event.EventCategory,
                        "event_time_generated": event.TimeGenerated
                    })
        progress_bar(i + 1, total, "Reading log ", Fore.YELLOW)
    return events_info


if __name__ == "__main__":

    start_log()

    csv_file = "../flussi/evt.csv"
    xml_file = "../flussi/evt.xml"
    events = get_event_info()
    file_writer = Writer()
    file_writer.write(csv_file, events)
    file_writer.write(xml_file, events)
    print(Style.RESET_ALL, '\a')

    end_log()
