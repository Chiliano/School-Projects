#!/usr/bin/env python3

"""
Rapresents a file writer.
This writer supports 3 data formats: csv, xml, json
"""

import platform
import time
from datetime import datetime
from lxml import etree as xml
from os.path import exists
from icecream import ic
from colorama import Fore
from utility import progress_bar


class Writer:

    """
    Class Writer:
    can be used to write csv, xml and json file
    """

    def __init__(self) -> None:

        """Writer constructor"""

        pass

    def write(self, file_path: str, col_item: list[dict]):

        """
        This method write the given content in a formatted file.

        :param  file_path:  The path of the file must
                col_item :  
        """

        format = file_path.split('.')[-1]

        if format == "csv":
            header, content = self.to_csv(col_item)
            if exists(file_path):
                with open(file_path, "a") as csv:
                    csv.write(content)
            else:
                with open(file_path, "a") as csv:
                    csv.write(header + '\n' + content)

        elif format == "xml":
            content = self.to_xml(col_item)
            xml.indent(content, space="\t", level=0)
            content.write(file_path, encoding='utf-8', xml_declaration=True)

        elif format == "json":
            ic("JSON will be implemented as soon as possible")

        else:
            ic("Unknown format")


    def to_csv(self, col_item: list[dict]) -> str and str:

        """
        """

        keys = col_item[0].keys()
        header = "unix_time;date;operative_system;hostname;" + ';'.join(keys)
        device_info = (
            f"{str(time.time())};{str(datetime.now())};" + \
            f"{platform.system().lower()};{platform.node()};"
        )
        content = ""

        for i, item in enumerate(col_item):
            content += f"{device_info}"
            for key in keys:
                content += f"{item[key]};"
            content += "\n"
            progress_bar(i + 1, len(col_item), "Writing csv ", Fore.YELLOW)

        return header, content


    def to_xml(self, col_item: list[dict]) -> xml:

        """
        """

        keys = col_item[0].keys()

        root = xml.Element("root")
        css = xml.ProcessingInstruction("xml-stylesheet", text='type="text/css" href="style.css"')
        root.addprevious(css)

        for i, item in enumerate(col_item):
            element = xml.SubElement(root, "item")
            unix_time = xml.SubElement(element, "unix_time")
            unix_time.text= str(time.time())
            date = xml.SubElement(element, "date")
            date.text= str(datetime.now())
            os = xml.SubElement(element, "operative_system")
            os.text= platform.system().lower()
            hostname = xml.SubElement(element, "hostname")
            hostname.text= platform.node()
            for key in keys:
                property = xml.SubElement(element, key)
                property.text = str(item[key])

                tree = xml.ElementTree(root)
                
            progress_bar(i + 1, len(col_item), "Writing xml ", Fore.YELLOW)

        return tree

