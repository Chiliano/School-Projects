#!/usr/bin/env python3

"""
This script trace the main program's execution.

    return: trace.log (file)
"""


import platform
import time
from datetime import datetime
from functools import wraps
from time import perf_counter
from icecream import ic
from colorama import Fore


def progress_bar(progress, total, message, color):

    """
    Progress bar in the terminal

    param   progress: int
            total: int
            argument: string
            color: class
    """

    percent = 100 * (progress / float(total))
    loading_bar = '■' * int(percent) + '-' * (100 - int(percent))
    print(color + f"\r{message}|{loading_bar}|{percent:.2f}%", end='\r')
    if progress == total:
        print(Fore.GREEN + f"\r{message}|{loading_bar}| {percent:.2f}%", end='\r')
        print(end='\n')


def get_time(func):
    """
    Decorator to time every function
    """
    @wraps(func)
    def wrapper(*args, **kwargs):

        start_time = perf_counter()
        func(*args, **kwargs)
        end_time = perf_counter()
        total_time = round(end_time - start_time, 6)

        return total_time

    return wrapper


@get_time
def start_log():

    """
    Trace the start of the program in the .log file
    """
    # Open file in append
    with open("../log/trace.log", "a", encoding="UTF-8") as trace:
        # Writing date, platform, device name
        trace.write(f"{str(time.time())};{str(datetime.now())};" + \
                    f"{platform.system().lower()};{platform.node()}" + \
                    ";START\n")


@get_time
def end_log():

    """
    Trace the end of the program in the .log file
    """
    # Open file in append
    with open("../log/trace.log", "a", encoding="UTF-8") as trace:
        # Writing date, platform, device name
        trace.write(f"{str(time.time())};{str(datetime.now())};" + \
                    f"{platform.system().lower()};{platform.node()}" + \
                    ";END\n")


if __name__ == "__main__":

    print("<", end="")
    ic.disable()
    ic.configureOutput(includeContext=True)
    ic(f"Time: {start_log()} s")
    ic(f"Time: {end_log()} s")
    print(">", end="")
