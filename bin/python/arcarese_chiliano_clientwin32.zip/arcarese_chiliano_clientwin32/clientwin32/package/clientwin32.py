#!/usr/bin/env python3

"""
    Client win32 for registry reading
"""

from datetime import datetime
import platform
import os
import time
from tqdm import tqdm
import win32com.client
import pandas as pd
from utility import log


BOOL_D = False


def get_network_adapter_configuration():

    """
    Return a dataframe based on the Win32_NetworkAdapterConfiguration object

        return: df
    """

    # Send query filtered to the registry
    selector = "SELECT * FROM Win32_NetworkAdapterConfiguration WHERE IPEnabled = 'True'"
    col_items = wmi.ExecQuery(selector)

    unix_date, date, host, cap, ip_address = [], [], [], [], []
    sub, mac, gate, dhcp = [], [], [], []

    # Loading bar
    for i in tqdm(col_items, desc = "Win32_NetworkAdapterConfiguration "):
        del i

        # Init columns content
        for item in col_items:

            # Add date in unix format of the item to the column UnixDate
            unix_date.append(str(time.time()))
            # Add date of the item to the column date
            date.append(str(datetime.now()))
            # Add DNSHostName of the item to the column DNSHostName
            host.append(item.DNSHostName)
            # Add Caption of the item to the column Caption
            cap.append(item.Caption)
            # Add IPAdress of the item to the column IPAdress
            ip_address.append(item.IPAddress[0])
            # Add IPSubnet of the item to the column IPSubnet
            sub.append(item.IPSubnet[0])
            # Add MACAddress of the item to the column MACAddress
            mac.append(item.MACAddress)
            # Add DefaultIPGateway of the item to the column DefaultIPGateway
            if item.DefaultIPGateway is not None:
                # If exist get only IPv4
                gate.append(item.DefaultIPGateway[0])
            else:
                gate.append(str(item.DefaultIPGateway))
            # Add DHCPServer of the item to the column DHCPServer
            dhcp.append(str(item.DHCPServer))

        # Loading bar progression
        time.sleep(0.02)


    # Dictionary to create dataset for the dataframe
    network_adapter = {
                        "UnixDate": unix_date,
                        "Date": date,
                        "DNSHostName": host,
                        "Caption": cap,
                        "IPAdress": ip_address,
                        "IPSubnet": sub,
                        "MACAddress": mac,
                        "DefaultIPGateway": gate,
                        "DHCPEnabled": dhcp,
                       }

    # Return the created dataframe
    return create_df(network_adapter)



def get_product():

    """
    Return a dataframe based on the Win32_Product object

        return: df
    """

    # Send query filtered to the registry
    col_items = wmi.ExecQuery("SELECT * FROM Win32_Product")

    unix_date, date, name, ver, cap, ven, leng, device_name = [], [], [], [], [], [], [], []

    # Loading bar
    for i in tqdm(range(10), desc = "Win32_Product "):
        del i

        # Init columns content
        for item in col_items:

            # Add date in unix format of the item to the column UnixDate
            unix_date.append(str(time.time()))
            # Add date of the item to the column date
            date.append(str(datetime.now()))
            # Add Host of the item to the column Host
            device_name.append(platform.node())
            # Add Name of the item to the column Name
            name.append(item.Name)
            # Add InstallLocation of the item to the column InstallLocation
            ver.append(item.Version)
            # Add Caption of the item to the column Caption
            cap.append(item.Caption)
            # Add Vendor of the item to the column Vendor
            ven.append(item.Vendor)
            # Add Language of the item to the column Language
            leng.append(item.Language)

        # Loading bar progression
        time.sleep(0.02)


    # Dictionary to create dataset for the dataframe
    product = {
                "UnixDate": unix_date,
                "Date": date,
                "DeviceName": device_name,
                "ProductName": name,
                "Version": ver,
                "Caption": cap,
                "Vendor": ven,
                "Language": leng,
               }

    # Return the created dataframe
    return create_df(product)


def get_user_profile():

    """
    Return a dataframe based on the Win32_UserProfile e Win32_UserAccount object

        return: df
    """

    # Send query to the registry
    col_items = wmi.ExecQuery("SELECT * FROM Win32_UserProfile")
    col_users = wmi.ExecQuery("SELECT * FROM Win32_UserAccount")

    unix_date, date, name, sid, last_use_time, device_name = [], [], [], [], [], []

    # Loading bar
    for i in tqdm(col_items, desc = "Win32_UserProfile "):
        del i

        # Init columns content
        for item in col_items:
            for user in col_users:
                if user.SID == item.SID:
                    # Add date in unix format of the item to the column UnixDate
                    unix_date.append(str(time.time()))
                    # Add date of the item to the column date
                    date.append(str(datetime.now()))
                    # Add Host of the item to the column Host
                    device_name.append(platform.node())
                    # Add Name of the user to the column Name
                    name.append(user.Name)
                    # Add SID of the user to the column SID
                    sid.append(user.SID)
                    # Add LastUseTime of the item to the column LastUseTime
                    last_use_time.append(item.LastUseTime)

                # Loading bar progression
                time.sleep(0.02)


    # Dictionary to create dataset for the dataframe
    user_profile = {
                "UnixDate": unix_date,
                "Date": date,
                "DeviceName": device_name,
                "ProfileName": name,
                "SID": sid,
                "LastUseTime": last_use_time,
            }

    # Return the created dataframe
    return create_df(user_profile)


def get_cluster_share():

    """
    Return a dataframe based on the Win32_UserProfile e Win32_ClusterShare object

        return: create_df(cluster_share)
    """

    # Send query to the registry
    col_items = wmi.ExecQuery("SELECT * FROM Win32_ClusterShare")

    unix_date, date, name, status, path, device_name = [], [], [], [], [], []

    # Loading bar
    for i in tqdm(col_items, desc = "Win32_UserProfile "):
        del i

        # Init columns content
        for item in col_items:

            # Add date in unix format of the item to the column UnixDate
            unix_date.append(str(time.time()))
            # Add Date of the item to the column Date
            date.append(str(datetime.now()))
            # Add Host of the item to the column Host
            device_name.append(platform.node())
            # Add Name of the item to the column Name
            name.append(item.Name)
            # Add Status of the item to the column Status
            status.append(item.Status)
            # Add Path of the item to the column Path
            path.append(item.Path)

        # Loading bar progression
        time.sleep(0.02)



    # Dictionary to create dataset for the dataframe
    cluster_share = {
                "UnixDate": unix_date,
                "Date": date,
                "DeviceName": device_name,
                "ShareName": name,
                "Status": status,
                "Path": path,
            }

    # Return the created dataframe
    return create_df(cluster_share)


def create_df(data_set):

    """
    Create a dataframe with the assigned dataset
    Can print debugging utility

        return: data_frame
    """

    # Init product's dataframe
    data_frame = pd.DataFrame(data = data_set)

    # Debugging utility
    if BOOL_D:
        print(data_frame)

    return data_frame


def store_data_to_csv(current_df, file, last_column):

    """
    Store dataframe in csv file
    """

    if os.path.exists("../flussi/" + file + ".csv"):
        # Concatenate the previous dataframe in the csv file with the new dataframe
        previous_df = pd.read_csv("../flussi/" + file + ".csv", sep = ";", engine = "python")
        current_df = pd.concat([current_df, previous_df], ignore_index = True)
        # Cut the extra columns from the dataframe
        final_current_df = current_df.drop(current_df.loc[:, last_column:].columns, axis = 1)
        # Store the concatenated dataframe in a csv file
        final_current_df.to_csv("../flussi/" + file + ".csv", sep = ";")
    else:
        # Create a new csv file for data storing
        current_df.to_csv("../flussi/" + file + ".csv", sep = ";")



if __name__ == "__main__":

    log()

    # Inizialize client win32
    wmi = win32com.client.GetObject(r"winmgmts://./root/cimv2")

    df_list = []

    print() # Spacing
    df_list.append(get_network_adapter_configuration())
    print() # Spacing
    df_list.append(get_product())
    print() # Spacing
    df_list.append(get_user_profile())
    print() # Spacing
    df_list.append(get_cluster_share())
    print() # Spacing

    file_names = ["df_NetworkAdapter", "df_Product", "df_UserProfile", "df_ClusterShare"]
    last_columns_list = ["DHCPEnabled", "Language", "LastUseTime", "Path"]


    # Loading bar
    for j in tqdm(range(4), desc = "CSV_conversion "):
        # Storing dataframe in csv files
        store_data_to_csv(df_list[j], file_names[j], last_columns_list[j])
        # Loading bar progression
        time.sleep(0.02)
