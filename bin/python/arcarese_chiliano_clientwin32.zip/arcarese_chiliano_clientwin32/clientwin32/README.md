# Client win32

![Platform](https://img.shields.io/badge/OS%20platform%20supported-Windows-blue?style=flat)
![Language](https://img.shields.io/badge/Language-Python-yellowgreen?style=flat)
![Language](https://img.shields.io/badge/Spellcheck-Pass-green?style=flat)
![Testing](https://img.shields.io/badge/Pylint-10.00-green)
![Testing](https://img.shields.io/badge/Test-Pass-green)

## Descrizione

- Il programma crea un client win32 in grado di leggere il registry di sistema.
- I dati letti sono riguardanti le seguenti classi:
    + Win32_Product
    + Win32_UserAccount
    + Win32_ClusterShare
    + Win32_NetworkAdapterConfiguration

- I dati raccolti sono poi memorizzati in file csv presenti nella cartella flussi.
- I 4 file rappresentano lo storico delle specifiche proprietà della macchina.

## Requisiti

- python3
- Librerie:
  + pywin32
  + pandas
  + tqdm
- py venv (consigliato)

## Esecuzione

Eseguire il programma da linea comando all'interno del pacchetto.
Si consiglia di utilizzare un python virtual env.

## Tags

CIM, Win32_Classes, Security, Registry, Windows OS, Client, File System, Data Frame, Pandas, Loading Bar, System Hardening

## Author

Chiliano Arcarese
