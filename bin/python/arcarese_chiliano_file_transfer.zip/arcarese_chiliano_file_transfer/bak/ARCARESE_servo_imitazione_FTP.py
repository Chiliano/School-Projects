#!/usr/bin/env python3

"""
This script implements a file transfer server using UDP.
"""

import socket
from os import makedirs, listdir
from os.path import join, exists, getsize, split
from net_sockets import NetSockets


def server_logic(server_socket: socket) -> None:
    """
    Logic for the file transfer server.

    Parameters:
    - server_socket (socket): The server socket.

    Returns:
    - None
    """

    default_dir = r"./server_disk/"
    buffer_size = 1024

    if not exists(default_dir):
        makedirs(default_dir)

    while True:
        print("[-] Listening...")
        request, address = server_socket.recvfrom(buffer_size)

        if request.decode("ISO-8859-1") == "upload":
            upload_file(server_socket, buffer_size, default_dir)

        elif request.decode("ISO-8859-1") == "listfile":
            list_file(server_socket, default_dir, address)

        elif request.decode("ISO-8859-1") == "download":
            download_file(server_socket, buffer_size, default_dir)


def upload_file(_server_sock: socket, _buffer: int, _dir: str) -> None:
    """
    Uploads a file received over the given server socket and saves
    it in the specified directory.

    Parameters:
    - _server_sock (socket): The server socket for communication.
    - _buffer (int): The buffer size for receiving data chunks.
    - _dir (str): The directory where the uploaded file will be saved.

    Returns:
    - None
    """
    file, address = _server_sock.recvfrom(_buffer)
    root, file_name = split(file:=file.decode("ISO-8859-1"))
    print(f"[+] Received request to upload file: {file} from {address}")

    try:
        with open(join(_dir, file), "wb") as file:
            while True:
                chunk, _ = _server_sock.recvfrom(_buffer)
                if chunk.decode("ISO-8859-1") == "EOF":
                    break
                print("\tWrite chunk")
                file.write(chunk)
        print(f"\tFile {file_name} received and saved.")
    except FileNotFoundError:
        print(root)


def list_file(_server_sock: socket, _dir: str, ip_addr: str) -> None:
    """
    Sends a list of files in the specified directory to the client
    over the given server socket.

    Parameters:
    - _server_sock (socket): The server socket for communication.
    - _dir (str): The directory containing the files to list.
    - ip_addr (str): The IP address of the client.

    Returns:
    - None
    """
    print(f"[+] Received request to list files from {ip_addr}")
    files = str(
        [
            f"{file: <30} |" + f"{getsize(join(_dir, file)): >5} bytes"
            for file in listdir(_dir)
        ]
    )
    _server_sock.sendto(files.encode(), ip_addr)


def download_file(_server_sock: socket, _buffer: int, _dir: str) -> None:
    """
    Sends a requested file to the client over the given server socket.

    Parameters:
    - _server_sock (socket): The server socket for communication.
    - _buffer (int): The buffer size for sending data chunks.
    - _dir (str): The directory where the requested file is located.

    Returns:
    - None
    """
    filename, address = _server_sock.recvfrom(_buffer)
    filename = filename.decode("ISO-8859-1")
    file_size = getsize(join(_dir, filename))
    _server_sock.sendto(str(file_size).encode(), address)

    print(f"[+] Received request to download file: {filename} from {address}")
    with open(join(_dir, filename), "rb") as file:
        while True:
            chunk = file.read(_buffer)
            if not chunk:
                break
            print("\tRead chunk")
            _server_sock.sendto(chunk, address)
        _server_sock.sendto("EOF".encode(), address)
    print(f"\tFile {filename} transmitted.")


if __name__ == "__main__":
    print(
        """
        \r┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
        \r┃     File transfer imitation     ┃
        \r┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
        \r   Server: 127.0.0.1 | port: 69
        \r  ──────────────────────────────
          """
    )

    server = NetSockets(
        socket_type="server",
        protocol="udp",
        server_name="127.0.0.1",
        port=69,
        logic=server_logic,
    )
    server.start_udp_server()
