#!/usr/bin/env python3

"""
This script implements a client for file transfer using UDP.
"""

import socket
from sys import argv
from os import makedirs, walk
from os.path import getsize, exists, join, isdir, split
from colorama import Fore, init
from net_sockets import NetSockets, progress_bar


def client_logic(client_socket: socket, server: tuple) -> None:
    """
    Logic for the file transfer client.

    Parameters:
    - client_socket (socket): The client socket.
    - server (tuple): The server address (host, port).

    Raises:
    - IndexError: If no commands are provided.

    Returns:
    - None
    """

    default_dir = r"./client_disk"
    buffer_size = 1024
    args = [a.lower() for a in argv]

    if not exists(default_dir):
        makedirs(default_dir)

    if "upload" in args:
        if isdir(args[3]):
            upload_dir(client_socket, buffer_size, server, args[3])
        else:
            upload_file(client_socket, buffer_size, server, args[3])

    elif "listfile" in args:
        list_file(client_socket, buffer_size, server)

    elif "download" in args:
        download_file(client_socket, buffer_size, default_dir, args[3], server)

    else: raise IndexError


def upload_dir(
    _client_sock: socket, _buffer: int, server_addr: str, dir_path: str
    ) -> None:
    """
    """
    for root, _, files in walk(dir_path):
        for file in files:
            upload_file(_client_sock, _buffer, server_addr, join(root, file))



def upload_file(
    _client_sock: socket, _buffer: int, server_addr: str, file_path: str
) -> None:
    """
    Uploads a file to the server using the given client socket.

    Parameters:
    - _client_sock (socket): The client socket for communication.
    - _buffer (int): The buffer size for sending data chunks.
    - server_addr (str): The server address to upload the file.
    - file_path (str): The path to the file to be uploaded.

    Returns:
    - None
    """
    if not exists(file_path):
        print(f"Error: File '{file_path}' not found.")
        return

    _client_sock.sendto("upload".encode("ISO-8859-1"), server_addr)
    root, file_name = split(file_path)
    _client_sock.sendto(file_path.encode("ISO-8859-1"), server_addr)

    file_size = getsize(file_path)
    print(f"\nUploading {file_name}... {file_size} bytes")

    init()

    with open(file_name, "rb") as file:
        i = 1
        while True:
            chunk = file.read(_buffer)
            if not chunk:
                break
            _client_sock.sendto(chunk, server_addr)
            progress_bar(i, file_size, "Uploading file...")
            i += len(chunk)

            progress = min(100, int(i / file_size * 100))
            progress_bar(progress, 100, "Uploading file...", color=Fore.GREEN)

        if i < file_size:
            progress_bar(100, 100, "Uploading file...", color=Fore.GREEN)
        _client_sock.sendto("EOF".encode("ISO-8859-1"), server_addr)

    print(f"{file_name} uploaded successfully.")


def list_file(_client_sock: socket, _buffer: int, server_addr: str) -> None:
    """
    Requests and prints the list of files available on the server using the given client socket.

    Parameters:
    - _client_sock (socket): The client socket for communication.
    - _buffer (int): The buffer size for receiving data.

    Returns:
    - None
    """
    _client_sock.sendto("listfile".encode("ISO-8859-1"), server_addr)
    server_files, _ = _client_sock.recvfrom(_buffer)
    server_files = server_files.decode()[1:-1].split(",")
    print("\nServer's shared folder:\n", "─" * 45, sep="")
    for file in server_files:
        print(file.strip()[1:-1])


def download_file(
    _client_sock: socket, _buffer: int, _dir: str, file_name: str, server_addr: str
) -> None:
    """
    Downloads a file from the server using the given client socket
    and saves it in the specified directory.

    Parameters:
    - _client_sock (socket): The client socket for communication.
    - _buffer (int): The buffer size for receiving data chunks.
    - _dir (str): The directory where the downloaded file will be saved.
    - file (str): The name of the file to be downloaded.

    Returns:
    - None
    """
    _client_sock.sendto("download".encode("ISO-8859-1"), server_addr)
    _client_sock.sendto(file_name.encode("ISO-8859-1"), server_addr)

    file_size, server_addr = _client_sock.recvfrom(_buffer)
    file_size = int(file_size.decode())
    print(f"\nDownloading file... {file_size} bytes")

    init()

    with open(join(_dir, file_name), "wb") as file:
        i = 0
        while True:
            chunk, _ = _client_sock.recvfrom(_buffer)
            if chunk.decode() == "EOF":
                break
            file.write(chunk)
            progress_bar(i, file_size, f"Downloading {file_name}...")
            i += len(chunk)

            progress = min(100, int(i / file_size * 100))
            progress_bar(progress, 100, f"Downloading {file_name}...", color=Fore.GREEN)

        if i < file_size:
            progress_bar(100, 100, f"Downloading {file_name}...", color=Fore.GREEN)
        _client_sock.sendto("EOF".encode("ISO-8859-1"), server_addr)

        print(
            f"File {file} received and saved. \
            \r\nStored in {join(_dir, file_name)}"
        )


if __name__ == "__main__":
    try:
        client = NetSockets(
            socket_type="client",
            protocol="UDP",
            server_name=argv[1],
            port=69,
            timeout=60,
            logic=client_logic,
        )
        client.start_udp_client()
    except IndexError:
        print(
            """
            \rUsage:
            \r- To upload a file:
            \r    python ARCARESE_cliente_imitazione_FTP.py <server_ip> upload >path/to/file.txt
            \r- To list files on the server:
            \r    python ARCARESE_cliente_imitazione_FTP.py <server_ip> listfile
            \r- To download a file:
            \r    python ARCARESE_cliente_imitazione_FTP.py <server_ip> download filename.txt
            """
        )
