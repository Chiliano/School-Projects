# File Transfer Project

![GitHub](https://img.shields.io/badge/GitHub-Chiliano%20Arcarese-darkgray?&logo=GitHub)
![Testing](https://img.shields.io/badge/Test-Pass-green)
![Language](https://img.shields.io/badge/Spellcheck-√-green?style=flat)
![Language](https://img.shields.io/badge/Language-Python-yellow?style=flat&logo=python&logoColor=yellow)

![Platform](https://img.shields.io/badge/OS%20platform%20supported-Windows-blue?style=flat&logo=windows&logoColor=blue)
![IDE](https://img.shields.io/badge/IDE-Visual_Studio_Code-blue?style=flat&logo=visualStudio&logoColor=blue)

This project implements a simple file transfer system using Python and UDP sockets.


## Table of Contents

- [Introduction](#introduction)
- [Features](#features)
- [Requirements](#requirements)
- [Installation](#installation)
- [Usage](#usage)
- [Pylint](#pylint)
- [Tags](#tags)


## Introduction

This Python project provides a basic implementation of a file transfer system using UDP sockets. It consists of a client and a server module that communicate with each other to upload, download, and list files.

## Features

- **Upload File:** Allows the client to upload a file to the server.
- **List Files:** Requests and displays the list of files available on the server.
- **Download File:** Allows the client to download a file from the server.

## Requirements

- Python 3.x
- Colorama library (install using `pip install colorama`)

## Installation

2. Install the Colorama library:

    ```bash
    pip install colorama
    ```

3. Run the server:

    ```bash
    python ARCARESE_servo_imitazione_FTP.py
    ```

4. Run the client:

    ```bash
    python ARCARESE_cliente_imitazione_FTP.py [upload/listfile/download]
    ```
>

## Usage

- To upload a file:

    ```bash
    python ARCARESE_cliente_imitazione_FTP.py upload path/to/file.txt
    ```

- To list files on the server:

    ```bash
    python ARCARESE_cliente_imitazione_FTP.py listfile
    ```

- To download a file:

    ```bash
    python ARCARESE_cliente_imitazione_FTP.py download filename.txt
    ```
>

$~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$

## Pylint:

[Pylint](http://pylint.org/) is a Python static code analysis tool which looks for programming errors and helps enforcing coding standards.

  ![Testing: 9.81/10](https://img.shields.io/badge/Pylint%20|%20Module:%20ARCARESE__servo__imitazione__FTP.py-9.81-green)
```bash
************* Module ARCARESE_servo_imitazione_FTP
ARCARESE_servo_imitazione_FTP.py:1:0: C0103: Module name "ARCARESE_servo_imitazione_FTP" doesn't conform to snake_case naming style (invalid-name)
```
<br>

---
<br>

![Testing 9.86/10](https://img.shields.io/badge/Pylint%20|%20Module:%20ARCARESE_cliente__imitazione__FTP.py-9.86-green)
```bash
************* Module ARCARESE_cliente_imitazione_FTP
ARCARESE_cliente_imitazione_FTP.py:1:0: C0103: Module name "ARCARESE_cliente_imitazione_FTP" doesn't conform to snake_case naming style (invalid-name)
```

<br>

---
<br>

![Testing: 9.74/10](https://img.shields.io/badge/Pylint%20|%20Module:%20net__sockets.py-9.74-green)
```bash
************* Module net_sockets
net_sockets.py:19:4: R0913: Too many arguments (7/5) (too-many-arguments)
net_sockets.py:133:0: R0902: Too many instance attributes (8/7)(too-many-instance-attributes)
net_sockets.py:138:4: R0913: Too many arguments (6/5) (too-many-arguments)
```

$~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$

## Tags

File Transfer, TFTP, Python, UDP, Networking, Colorama