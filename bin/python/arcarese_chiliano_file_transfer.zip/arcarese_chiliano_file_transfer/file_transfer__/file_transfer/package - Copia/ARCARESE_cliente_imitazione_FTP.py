#!/usr/bin/env python3

"""
This script implements a client for file transfer using UDP.
"""

import socket
from sys import argv
from os import environ, walk
from os.path import getsize, exists, join, isdir, split
from colorama import Fore, init
from net_sockets import NetSockets, progress_bar


def client_logic(client_socket: socket, server: tuple) -> None:
    """
    Logic for the file transfer client.

    Parameters:
    - client_socket (socket): The client socket.
    - server (tuple): The server address (host, port).

    Raises:
    - IndexError: If no commands are provided.

    Returns:
    - None
    """

    buffer_size = 1024
    args = [a.lower() for a in argv]

    if "upload" in args:
        if isdir(args[3]):
            upload_dir(client_socket, buffer_size, server, args[3])
        else:
            upload_file(client_socket, buffer_size, server, args[3])

    elif "listfile" in args:
        list_file(client_socket, buffer_size, server)

    elif "download" in args:
        download_file(client_socket, buffer_size, args[3], server)

    else:
        raise IndexError


def upload_dir(
    _client_sock: socket, _buffer: int, server_addr: str, base_dir: str
) -> None:
    """
    Recursively uploads all files in the specified directory and its subdirectories
    to the server using the given client socket.

    Parameters:
    - _client_sock (socket): The client socket for communication.
    - _buffer (int): The buffer size for sending data chunks.
    - server_addr (str): The server address to upload the files.
    - base_dir (str): The base directory to upload.

    Returns:
    - None
    """
    _client_sock.sendto("upload_dir".encode("ISO-8859-1"), server_addr)
    _client_sock.sendto(base_dir.encode("ISO-8859-1"), server_addr)

    for root, _, files in walk(base_dir):
        for file in files:
            _client_sock.sendto(
                join(root).encode("ISO-8859-1"), 
                server_addr
            )
            print(f"\nSending: {join(root, file)}\n")
            transfer_file(_client_sock, _buffer, server_addr, join(root, file))
            break
        break


    """
    file_path = join(root, file)
    rel_path = file_path[len(base_dir) + 1:]
    _client_sock.sendto(rel_path.encode("ISO-8859-1"), server_addr)

    # Add folder structure information for each file
    folder_structure = root[len(base_dir):]
    _client_sock.sendto(folder_structure.encode("ISO-8859-1"), server_addr)

    upload_file(_client_sock, _buffer, server_addr, file_path)"""

def upload_file(_client_sock: socket, _buffer: int, server_addr: str, file_path: str):
    if not exists(file_path):
        print(f"Error: File '{file_path}' not found.")
        return
    _client_sock.sendto("upload".encode("ISO-8859-1"), server_addr)

    transfer_file(_client_sock, _buffer, server_addr, file_path)


def transfer_file(
    _client_sock: socket, _buffer: int, server_addr: str, file_path: str
) -> None:

    _, file_name = split(file_path)
    file_size = getsize(file_path)
    print(f"\nUploading {file_name}... {file_size} bytes")

    init()

    with open(file_path, "rb") as file:
        i = 1
        while True:
            chunk = file.read(_buffer)
            if not chunk:
                break
            _client_sock.sendto(chunk, server_addr)
            progress_bar(i, file_size, "Uploading file...")
            i += len(chunk)

            progress = min(100, int(i / file_size * 100))
            progress_bar(progress, 100, "Uploading file...", color=Fore.GREEN)

        if i < file_size:
            progress_bar(100, 100, "Uploading file...", color=Fore.GREEN)
        _client_sock.sendto("EOF".encode("ISO-8859-1"), server_addr)

    print(f"{file_name} uploaded successfully.")


def list_file(_client_sock: socket, _buffer: int, server_addr: str) -> None:
    """
    Requests and prints the list of files available on the server using the given client socket.

    Parameters:
    - _client_sock (socket): The client socket for communication.
    - _buffer (int): The buffer size for receiving data.

    Returns:
    - None
    """
    _client_sock.sendto("listfile".encode("ISO-8859-1"), server_addr)
    server_files, _ = _client_sock.recvfrom(_buffer)
    server_files = server_files.decode("ISO-8859-1")[1:-1].split(",")
    print(f"\n{server_addr} → Server's shared folder:\n", "─" * 60, sep="")
    for file in server_files:
        print(file.strip()[1:-1])


def download_file(
    _client_sock: socket, _buffer: int, file_name: str, server_addr: str
) -> None:
    """
    Downloads a file from the server using the given client socket
    and saves it in the specified directory.

    Parameters:
    - _client_sock (socket): The client socket for communication.
    - _buffer (int): The buffer size for receiving data chunks.
    - file (str): The name of the file to be downloaded.

    Returns:
    - None
    """
    _dir = f"{environ['USERPROFILE']}\Downloads"

    _client_sock.sendto("download".encode("ISO-8859-1"), server_addr)
    _client_sock.sendto(file_name.encode("ISO-8859-1"), server_addr)

    file_size, server_addr = _client_sock.recvfrom(_buffer)
    if file_size.decode() == "FileNotFound":
        print("\nFILE NOT FOUND ERROR: please check file's name.")
        return
    file_size = int(file_size.decode("ISO-8859-1"))
    print(f"\nDownloading file... {file_size} bytes")

    init()

    with open(join(_dir, file_name), "wb") as file:
        i = 0
        while True:
            chunk, _ = _client_sock.recvfrom(_buffer)
            if chunk.decode("ISO-8859-1") == "EOF":
                break
            file.write(chunk)
            progress_bar(i, file_size, f"Downloading {file_name}...")
            i += len(chunk)

            progress = min(100, int(i / file_size * 100))
            progress_bar(progress, 100, f"Downloading {file_name}...", color=Fore.GREEN)

        if i < file_size:
            progress_bar(100, 100, f"Downloading {file_name}...", color=Fore.GREEN)
        _client_sock.sendto("EOF".encode("ISO-8859-1"), server_addr)

        print(
            f"File {file_name} received and saved. \
            \r\nStored in {join(_dir, file_name)}"
        )


if __name__ == "__main__":
    try:
        client = NetSockets(
            socket_type="client",
            protocol="UDP",
            server_name=argv[1],
            port=69,
            timeout=5,
            logic=client_logic,
        )
        client.start_udp_client()
    except IndexError:
        print(
            """
            \rUsage:
            \r
            \r- To upload a file or a directory:
            \r    python ARCARESE_cliente_imitazione_FTP.py <server_ip> upload <path>
            \r
            \r- To list files on the server:
            \r    python ARCARESE_cliente_imitazione_FTP.py <server_ip> listfile
            \r
            \r- To download a file:
            \r    python ARCARESE_cliente_imitazione_FTP.py <server_ip> download <filename>
            \r
            """
        )
    except socket.timeout as st:
        print(
            f"\n- SOCKET ERROR: {st}. Server doesn't responde in the setted timeout limits."
        )
