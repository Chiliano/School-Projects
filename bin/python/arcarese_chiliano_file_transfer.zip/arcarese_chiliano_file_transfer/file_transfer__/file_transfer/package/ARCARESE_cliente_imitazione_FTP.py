#!/usr/bin/env python3

"""
This script implements a client for file transfer using UDP.
"""

import socket
from sys import argv
from os import environ, walk
from os.path import getsize, exists, join, isdir, split
from colorama import Fore, init
from net_sockets import NetSockets, progress_bar


def client_logic(client_socket: socket, server: tuple) -> None:
    """
    Logic for the file transfer client.

    Parameters:
    - client_socket (socket): The client socket.
    - server (tuple): The server address (host, port).

    Raises:
    - IndexError: If no commands are provided.

    Returns:
    - None
    """

    buffer_size = 1024
    args = [a.lower() for a in argv]

    if "upload" in args:
        upload_request(client_socket, buffer_size, server, args[3])
"""
    elif "listfile" in args:
        list_file(client_socket, buffer_size, server)

    elif "download" in args:
        download_file(client_socket, buffer_size, args[3], server)

    else:
        raise IndexError
"""


def upload_request(_client_sock, _buffer, server_addr, file_path):
    
    # Check file existance and send request
    if not exists(file_path):
        print(f"Error: File '{file_path}' not found.")
        return
    _client_sock.sendto("upload".encode("ISO-8859-1"), server_addr)

    # Send file
    _, file_name = split(file_path)
    file_size = getsize(file_path)
    print(f"\nUploading {file_name}... {file_size} bytes")

    init()

    with open(file_path, "rb") as file:
        i = 1
        while True:
            chunk = file.read(_buffer)
            if not chunk:
                break
            _client_sock.sendto(i, server_addr)
            _client_sock.sendto(chunk, server_addr)
            progress_bar(i, file_size, "Uploading file...")
            i += len(chunk)

            progress = min(100, int(i / file_size * 100))
            progress_bar(progress, 100, "Uploading file...", color=Fore.GREEN)

        if i < file_size:
            progress_bar(100, 100, "Uploading file...", color=Fore.GREEN)
        _client_sock.sendto("EOF".encode("ISO-8859-1"), server_addr)

    print(f"{file_name} uploaded successfully.")

def send_file():
    ...



if __name__ == "__main__":
    try:
        client = NetSockets(
            socket_type="client",
            protocol="UDP",
            server_name=argv[1],
            port=69,
            timeout=5,
            logic=client_logic,
        )
        client.start_udp_client()
    except IndexError:
        print(
            """
            \rUsage:
            \r
            \r- To upload a file or a directory:
            \r    python ARCARESE_cliente_imitazione_FTP.py <server_ip> upload <path>
            \r
            \r- To list files on the server:
            \r    python ARCARESE_cliente_imitazione_FTP.py <server_ip> listfile
            \r
            \r- To download a file:
            \r    python ARCARESE_cliente_imitazione_FTP.py <server_ip> download <filename>
            \r
            """
        )
    except socket.timeout as st:
        print(
            f"\n- SOCKET ERROR: {st}. Server doesn't responde in the setted timeout limits."
        )
