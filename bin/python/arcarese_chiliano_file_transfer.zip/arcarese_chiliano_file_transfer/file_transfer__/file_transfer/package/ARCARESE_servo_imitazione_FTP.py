#!/usr/bin/env python3

"""
This script implements a file transfer server using UDP.
"""

import socket
from os import makedirs, listdir, walk, chdir, getcwd
from os.path import join, split, exists, getsize, isfile
from net_sockets import NetSockets


def server_logic(server_socket: socket) -> None:
    """
    Logic for the file transfer server.

    Parameters:
    - server_socket (socket): The server socket.

    Returns:
    - None
    """

    default_dir = r"./server_disk"
    buffer_size = 1024

    if not exists(default_dir):
        makedirs(default_dir)

    while True:
        print("[-] Listening...")
        request, address = server_socket.recvfrom(buffer_size)

        if request.decode("ISO-8859-1") == "upload":
            upload_request(server_socket, buffer_size, default_dir)
"""
        elif request.decode("ISO-8859-1") == "upload_dir":
            upload_dir(server_socket, buffer_size, default_dir)

        elif request.decode("ISO-8859-1") == "listfile":
            list_file(server_socket, default_dir, address)

        elif request.decode("ISO-8859-1") == "download":
            download_file(server_socket, buffer_size, default_dir)
"""

def upload_request(_server_sock, _buffer, _dir):

    file_path, address = _server_sock.recvfrom(_buffer)
    file_path = file_path.decode("ISO-8859-1")

    root, file_name = split(file_path)
    print(f"[+] Received request to upload file: {file_name} from {address}")



def receve_file(_server_sock, _buffer):
    
    file = {}
    receving = True
    index_list = []
    chunk_list = []

    while receving:
        index, _ = _server_sock.recvfrom(_buffer)
        chunk, _ = _server_sock.recvfrom(_buffer)
        file.update({index: chunk})
        index_list.append(index)
        chunk_list.append(chunk)
        if file_ended(index_list, chunk_list):
            receving = False
    return file


def file_ended():
    [for i in index_list]

def write_file(file_chunks):
    with open(file_path, "wb") as file:
        file.write()
    

def file_exists(_dir: str, file: str) -> bool:
    """
    Check if a file exists in the specified directory.

    Parameters:
    - _dir (str): The directory path to check for the file.
    - file (str): The name of the file to check for.

    Returns:
    - bool: True if the file exists in the directory, False otherwise.
    """
    for _, _, files in walk(_dir):
        if file in files:
            return True
    return False



if __name__ == "__main__":
    print(
        """
        \r┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
        \r┃     File transfer imitation     ┃
        \r┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
        \r   Server: 127.0.0.1 | port: 69
        \r  ──────────────────────────────
          """
    )

    server = NetSockets(
        socket_type="server",
        protocol="udp",
        server_name="127.0.0.1",
        port=69,
        logic=server_logic,
    )
    server.start_udp_server()
