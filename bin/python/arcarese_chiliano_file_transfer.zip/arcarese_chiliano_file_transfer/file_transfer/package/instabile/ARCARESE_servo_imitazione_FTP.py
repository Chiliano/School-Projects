#!/usr/bin/env python3

"""
This script implements a file transfer server using UDP.

The server listens for requests from clients and performs file upload,
file download, and file listing operations. User authentication is
handled based on a user database stored in 'users.csv'.

Usage:
- Run the script to start the file transfer server.
- The server listens on IP address 127.0.0.1 and port 69 by default.

Dependencies:
- The 'net_sockets' module is required for setting up the server.
- Ensure that 'users.csv' is present in the server's working directory.

Note: This script is part of a simulated file transfer system.

Author: Chiliano Arcarese
Date: 17/12/23

"""

import socket
from os import makedirs, listdir
from os.path import join, exists, getsize, split
from net_sockets import NetSockets


def server_logic(server_socket: socket) -> None:
    """
    Logic for the file transfer server.

    Parameters:
    - server_socket (socket): The server socket.

    Returns:
    - None
    """

    default_dir = r"./server_disk/"
    buffer_size = 1024

    if not exists(default_dir):
        makedirs(default_dir)

    while True:
        print("[-] Listening...")
        try:
            if not login(server_socket, buffer_size):
                continue
            request, address = server_socket.recvfrom(buffer_size)

            if request.decode("ISO-8859-1") == "upload":
                upload_file(server_socket, buffer_size, default_dir)

            elif request.decode("ISO-8859-1") == "listfile":
                list_file(server_socket, default_dir, address)

            elif request.decode("ISO-8859-1") == "download":
                download_file(server_socket, buffer_size, default_dir)
        except TimeoutError:
            continue


def login(_server_sock: socket, _buffer: int) -> bool:
    """
    Accept login request from client.

    Parameters:
    - _client_sock (socket): The client socket for communication.
    - _buffer (int): The buffer size for sending data chunks.

    Returns:
    - (bool): True if username and password are correct else False.
    """
    data, address = _server_sock.recvfrom(_buffer)
    data = data.decode("ISO-8859-1")

    if data.strip() == "anonymous;":
        print(f"[+] User {data.split(';')[0]} logged in from {address}")
        _server_sock.sendto("Anonymous".encode("ISO-8859-1"), address)
        return True

    with open(r".\users.csv", "r", encoding="ISO-8859-1") as usersfile:
        for line in usersfile:
            if data.strip() == line.strip():
                print(f"[+] User {data.split(';')[0]} logged in from {address}")
                _server_sock.sendto("Logged".encode("ISO-8859-1"), address)
                return True

    _server_sock.sendto("Rejected".encode("ISO-8859-1"), address)
    print(f"[+] {data.split(';')[0]} from {address} rejected")
    return False


def upload_file(_server_sock: socket, _buffer: int, _dir: str) -> None:
    """
    Uploads a file received over the given server socket and saves
    it in the specified directory.

    Parameters:
    - _server_sock (socket): The server socket for communication.
    - _buffer (int): The buffer size for receiving data chunks.
    - _dir (str): The directory where the uploaded file will be saved.

    Returns:
    - None
    """
    file_name, address = _server_sock.recvfrom(_buffer)
    file_name = file_name.decode("ISO-8859-1")
    print(f"[+] Received request to upload file: {file_name} from {address}")
    file_data = []

    while True:
        chunk, address = _server_sock.recvfrom(_buffer)
        chunk = chunk.decode("ISO-8859-1")
        chunk = chunk.split("|")
        file_data.append(chunk)
        _server_sock.sendto("ACK".encode("ISO-8859-1"), address)
        if "EOF" in chunk:
            break
    file_data.sort()

    with open(join(_dir, file_name), "w") as file:
        for chunk in file_data:
            file.write(chunk[1])
            print(f"\t{chunk[0]} bytes")
    print(f"\tFile {file_name} received and saved.")


def list_file(_server_sock: socket, _dir: str, ip_addr: str) -> None:
    """
    Sends a list of files in the specified directory to the client
    over the given server socket.

    Parameters:
    - _server_sock (socket): The server socket for communication.
    - _dir (str): The directory containing the files to list.
    - ip_addr (str): The IP address of the client.

    Returns:
    - None
    """
    print(f"[+] Received request to list files from {ip_addr}")
    files = str(
        [
            f"{file: <45} |" + f"{getsize(join(_dir, file)): >5} bytes"
            for file in listdir(_dir)
        ]
    )
    _server_sock.sendto(files.encode(), ip_addr)


def download_file(_server_sock: socket, _buffer: int, _dir: str) -> None:
    """
    Sends a requested file to the client over the given server socket.

    Parameters:
    - _server_sock (socket): The server socket for communication.
    - _buffer (int): The buffer size for sending data chunks.
    - _dir (str): The directory where the requested file is located.

    Returns:
    - None
    """
    filename, address = _server_sock.recvfrom(_buffer)
    filename = filename.decode("ISO-8859-1")
    file_size = getsize(join(_dir, filename))
    _server_sock.sendto(str(file_size).encode(), address)

    print(
        f"[+] Received request to download file: {filename} ({file_size} Byte) from {address}"
    )
    with open(join(_dir, filename), "rb") as file:
        while True:
            chunk = file.read(_buffer)
            if not chunk:
                break
            print("\tRead chunk")
            _server_sock.sendto(chunk, address)
        _server_sock.sendto("EOF".encode(), address)
    print(f"\tFile {filename} transmitted.")


if __name__ == "__main__":
    print(
        """
        \r┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
        \r┃     File transfer imitation     ┃
        \r┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
        \r   Server: 127.0.0.1 | port: 69
        \r  ──────────────────────────────
        """
    )

    server = NetSockets(
        socket_type="server",
        protocol="udp",
        server_name="127.0.0.1",
        port=69,
        logic=server_logic,
    )
    server.start_udp_server()
