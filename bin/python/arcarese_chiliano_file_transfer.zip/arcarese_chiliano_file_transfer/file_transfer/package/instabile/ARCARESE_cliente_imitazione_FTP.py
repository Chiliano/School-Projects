#!/usr/bin/env python3

"""
This script implements a client for file transfer using UDP.

Usage:
- To upload a file:
    python ARCARESE_cliente_imitazione_FTP.py <server_ip> <username> <password> upload path/to/file.txt

- To list files on the server:
    python ARCARESE_cliente_imitazione_FTP.py <server_ip> <username> <password>  listfile

- To download a file:
    python ARCARESE_cliente_imitazione_FTP.py <server_ip> <username> <password>  download filename.txt

Anonymous login:
- Username: Anonymous
- Password: ""

Dependencies:
- The 'net_sockets' module is required for setting up the client.
- Ensure that the 'colorama' module is installed for colored console output.

Note: This script is part of a simulated file transfer system.

Author: Chiliano Arcarese
Date: 17/12/23

"""

import socket
from sys import argv
from os import environ
from os.path import getsize, exists, join, split
from colorama import Fore, init
from net_sockets import NetSockets, progress_bar


def client_logic(client_socket: socket, server: tuple) -> None:
    """
    Logic for the file transfer client.
    Manages client-side file transfer actions based on command-line inputs.

    Parameters:
    - client_socket (socket): The client socket.
    - server (tuple): The server address (host, port).

    Raises:
    - ValueError: If provided an invalid username or password.
    - PermissionError: If an anonymous user attempts an unauthorized action.
    - IndexError: If no valid command or action is provided.

    Returns:
    - None
    """
    buffer_size = 1024
    args = [a.lower() for a in argv]
    logged = login(client_socket, buffer_size, server, args[2], args[3])
    print(f"Login status: {logged}")

    if logged == "Rejected":
        raise ValueError

    elif "upload" in args and logged == "Anonymous":
        raise PermissionError

    elif "upload" in args and logged == "Logged":
        upload_file(client_socket, buffer_size, server, args[5])

    elif "listfile" in args and (logged == "Logged" or logged == "Anonymous"):
        list_file(client_socket, buffer_size, server)

    elif "download" in args and (logged == "Logged" or logged == "Anonymous"):
        download_file(client_socket, buffer_size, args[5], server)

    else:
        raise IndexError


def login(
    _client_sock: socket, _buffer: int, server_addr: str, username: str, password: str
) -> str:
    """
    Send a login request to the server.

    Parameters:
    - _client_sock (socket): The client socket for communication.
    - _buffer (int): The buffer size for sending data chunks.
    - server_addr (str): The server address to send the login request.
    - username (str): The username for authentication.
    - password (str): The password for authentication.

    Returns:
    - (str): The server's response indicating login status.
    """
    packet = f"{username};{password}"
    _client_sock.sendto(packet.encode("ISO-8859-1"), server_addr)
    data, _ = _client_sock.recvfrom(_buffer)
    data = data.decode("ISO-8859-1")
    return data


def upload_file(
    _client_sock: socket, _buffer: int, server_addr: str, file_path: str
) -> None:
    """
    Uploads a file to the server using the given client socket.

    Parameters:
    - _client_sock (socket): The client socket for communication.
    - _buffer (int): The buffer size for sending data chunks.
    - server_addr (str): The server address to upload the file.
    - file_path (str): The path to the file to be uploaded.

    Returns:
    - None
    """
    if not exists(file_path):
        print(f"Error: File '{file_path}' not found.")
        return

    _client_sock.sendto("upload".encode("ISO-8859-1"), server_addr)
    _, file_name = split(file_path)
    _client_sock.sendto(file_name.encode("ISO-8859-1"), server_addr)

    file_size = getsize(file_path)
    print(f"\nUploading {file_name}... {file_size} bytes")

    init()

    with open(file_path, "rb") as file:
        i = 0
        while True:
            chunk = f"{i}|{file.read(512)}"
            print()
            if i > file_size:
                _client_sock.sendto(f"{i}|EOF".encode("ISO-8859-1"), server_addr)
                break
            _client_sock.sendto(chunk.encode("ISO-8859-1"), server_addr)
            ack, server_addr = _client_sock.recvfrom(_buffer)
            if ack:
                i += 1
                progress = min(100, int(i / file_size * 100))
                progress_bar(progress, 100, "Uploading file...", color=Fore.GREEN)
            
        if i < file_size:
            progress_bar(100, 100, "Uploading file...", color=Fore.GREEN)

    print(f"{file_name} uploaded successfully.")


def list_file(_client_sock: socket, _buffer: int, server_addr: str) -> None:
    """
    Requests and prints the list of files available on the server using the given client socket.

    Parameters:
    - _client_sock (socket): The client socket for communication.
    - _buffer (int): The buffer size for receiving data.
    - server_addr (str): The server address to send the list file request.

    Returns:
    - None
    """
    _client_sock.sendto("listfile".encode("ISO-8859-1"), server_addr)
    server_files, _ = _client_sock.recvfrom(_buffer)
    server_files = server_files.decode("ISO-8859-1")[1:-1].split(",")
    print(f"\n{server_addr} → Server's shared folder:\n", "─" * 60, sep="")
    for file in server_files:
        print(file.strip()[1:-1])


def download_file(
    _client_sock: socket, _buffer: int, file_name: str, server_addr: str
) -> None:
    """
    Downloads a file from the server using the given client socket
    and saves it in 'Download' directory.

    Parameters:
    - client_sock (socket): The client socket for communication.
    - buffer_size (int): The buffer size for receiving data chunks.
    - file_name (str): The name of the file to be downloaded.
    - server_addr (str): The server address.

    Returns:
    - None
    """
    _dir = f"{environ['USERPROFILE']}\Downloads"

    _client_sock.sendto("download".encode("ISO-8859-1"), server_addr)
    _client_sock.sendto(file_name.encode("ISO-8859-1"), server_addr)

    file_size, server_addr = _client_sock.recvfrom(_buffer)
    file_size = int(file_size.decode("ISO-8859-1"))
    print(f"\nDownloading file... {file_size} bytes")

    init()

    with open(join(_dir, file_name), "wb") as file:
        i = 0
        while True:
            chunk, _ = _client_sock.recvfrom(_buffer)
            if chunk.decode("ISO-8859-1") == "EOF":
                break
            file.write(chunk)
            progress_bar(i, file_size, f"Downloading {file_name}...")
            i += len(chunk)

            progress = min(100, int(i / file_size * 100))
            progress_bar(progress, 100, f"Downloading {file_name}...", color=Fore.GREEN)

        if i < file_size:
            progress_bar(100, 100, f"Downloading {file_name}...", color=Fore.GREEN)

        print(
            f"File {file_name} received and saved. \
            \r\nStored in {_dir}"
        )


if __name__ == "__main__":
    try:
        client = NetSockets(
            socket_type="client",
            protocol="UDP",
            server_name=argv[1],
            port=69,
            timeout=5,
            logic=client_logic,
        )
        client.start_udp_client()
    except IndexError:
        print(
            """
            \rUsage:
            \r\n- To upload a file:
            \r    python ARCARESE_cliente_imitazione_FTP.py <server_ip> <username> <password> upload path/to/file.txt
            \r\n- To list files on the server:
            \r    python ARCARESE_cliente_imitazione_FTP.py <server_ip> <username> <password> listfile
            \r\n- To download a file:
            \r    python ARCARESE_cliente_imitazione_FTP.py <server_ip> <username> <password> download filename.txt
            \r\nAnonymous login:
            \r\t- Username: Anonymous
            \r\t- Password: ""
            """
        )

    except TimeoutError:
        print("\nTimeout error. Please try again.")
    except PermissionError:
        print("\nPermission denied. Anonymous users can't perform this action.")
