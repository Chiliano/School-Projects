#!/usr/bin/env python3

"""
This script defines a utility class for creating custom server and
client sockets using Python's socket module.
"""

import socket
import random
from typing import Callable, Type
from colorama import Fore, init


class NetSockets:
    """
    A utility class for creating custom server and client sockets.
    """

    def __new__(
        cls,
        socket_type: str,
        protocol: str,
        server_name: str = "localhost",
        port: int = -1,
        timeout: int = -1,
        logic: Callable = None,
    ) -> Type["ServerSocket"] | Type["ClientSocket"]:
        """
        Create and return either a ServerSocket or ClientSocket instance based
        on the specified parameters.

        Parameters:
        - socket_type (str): Type of socket, either "server" or "client".
        - protocol (str): Type of protocol, either "TCP" or "UDP".
        - server_name (str): Server's name or IP address.
        - port (int): Port number for the socket.
        - timeout (int): Timeout value for the socket.

        Raises:
        - ValueError: Raised if an invalid socket type is provided.

        Returns:
        - ServerSocket | ClientSocket: An instance of ServerSocket or ClientSocket.
        """
        if socket_type.lower() == "server":
            return ServerSocket(protocol, port, server_name, timeout, logic)
        if socket_type.lower() == "client":
            return ClientSocket(protocol, port, server_name, timeout, logic)
        raise ValueError("Invalid Socket Type")

    @staticmethod
    def set_protocol(protocol: str) -> socket.SOCK_STREAM | socket.SOCK_DGRAM:
        """
        Convert the specified protocol string to the corresponding socket protocol constant.

        Parameters:
        - protocol (str): The protocol string, either "TCP" or "UDP".

        Returns:
        - socket.SOCK_STREAM | socket.SOCK_DGRAM: The socket protocol constant.

        Raises:
        - ValueError: Raised if an invalid protocol is provided.
        """
        if protocol.upper() == "TCP":
            return socket.SOCK_STREAM
        if protocol.upper() == "UDP":
            return socket.SOCK_DGRAM
        raise ValueError("Invalid Protocol")

    @staticmethod
    def set_application_logic(application_logic: Callable) -> Callable:
        """
        Set the application's logic function.

        Parameters:
        - application_logic (Callable): The function representing the application's logic.

        Returns:
        - Callable: The validated application logic function.
        """
        if not application_logic:
            raise NotImplementedError("Missing application's logic.")
        return application_logic

    @staticmethod
    def set_port(port: int) -> int:
        """
        Set and validate the port number.

        Parameters:
        - port (int): The port number.

        Returns:
        - int: The validated port number.
        """
        if 0 < port < 65536:
            return port
        return random.randint(49151, 65535)

    @staticmethod
    def set_timeout(timeout: int) -> int:
        """
        Set and validate the timeout value.

        Parameters:
        - timeout (int): The timeout value.

        Returns:
        - int: The validated timeout value.
        """
        if 0 < timeout < 65536:
            return timeout
        return 5

    @staticmethod
    def get_ip(server: str) -> str:
        """
        Get the IP address of the host.

        Parameters:
        - server (str): The server's name or IP.

        Returns:
        - str: The IP address.
        """
        if server in ("localhost", "127.0.0.1"):
            return "127.0.0.1"
        return socket.gethostbyname(socket.gethostname())


class ServerSocket:
    """
    A specialized class for creating and managing server sockets.
    """

    def __init__(
        self,
        protocol: str,
        port: int,
        server_type: str,
        timeout: int,
        server_logic: Callable,
    ) -> None:
        """
        Initialize the server socket instance with the specified parameters.

        Parameters:
        - protocol (str): The protocol to use, either "TCP" or "UDP".
        - port (int): The port number for the server socket.
        - timeout (int): The timeout value for the server socket.
        - server_logic (Callable): The function representing the server's logic.

        Raises:
        - NotImplementedError: Raised if server_logic is not provided.
        - ValueError: Raised if an invalid protocol is provided.
        """
        self.__server_logic = NetSockets.set_application_logic(server_logic)
        self.__protocol = NetSockets.set_protocol(protocol)
        self.__timeout = NetSockets.set_timeout(timeout)
        self.__port = NetSockets.set_port(port)
        self.__server_name = server_type
        self.__server_socket = None
        self.__client_addr = None
        self.__connection = None

    def start_tcp_server(self) -> None:
        """
        Initialize and run the server socket using TCP.

        Returns:
        - None
        """
        try:
            with socket.socket(socket.AF_INET, self.__protocol) as self.__server_socket:
                self.__server_socket.bind(
                    (NetSockets.get_ip(self.__server_name), self.__port)
                )
                while True:
                    self.__server_socket.listen()
                    self.__server_socket.settimeout(self.__timeout)
                    (
                        self.__connection,
                        self.__client_addr,
                    ) = self.__server_socket.accept()
                    self.__server_logic(self.__connection, self.__client_addr)
        except NotImplementedError:
            print("Please implement server's logic.")
        except KeyboardInterrupt:
            self.__server_socket.close()
        except socket.error as socket_error:
            print(f"Socket Error Occurred! {socket_error}")
            raise socket_error
        except Exception as exception:
            print(f"Exception in init_server: {exception}")
            raise exception

    def start_udp_server(self) -> None:
        """
        Initialize and run the server socket using UDP.

        Returns:
        - None
        """
        with socket.socket(socket.AF_INET, self.__protocol) as self.__server_socket:
            try:
                self.__server_socket.bind(
                    (NetSockets.get_ip(self.__server_name), self.__port)
                )
                self.__server_socket.settimeout(self.__timeout)
                self.__server_logic(self.__server_socket)
            except KeyboardInterrupt:
                self.__server_socket.close()
                print("Shutting down...")


class ClientSocket:
    """
    A specialized class for creating and managing client sockets.
    """

    def __init__(
        self,
        protocol: str,
        server_port: int,
        server: str,
        timeout: int,
        client_logic: Callable,
    ) -> None:
        """
        Initialize the client socket instance with the specified parameters.

        Parameters:
        - protocol (str): The protocol to use, either "TCP" or "UDP".
        - server_port (int): The port number for the server socket.
        - server (str): The server's name or IP address.
        - timeout (int): The timeout value for the client socket.
        - client_logic (Callable): The function representing the client's logic.
        """
        self.__client_logic = NetSockets.set_application_logic(client_logic)
        self.__server_port = NetSockets.set_port(server_port)
        self.__protocol = NetSockets.set_protocol(protocol)
        self.__timeout = NetSockets.set_timeout(timeout)
        self.__client_socket = None
        self.__server = server

    def start_tcp_client(self) -> None:
        """
        Initialize and run the client socket using TCP.
        """
        try:
            with socket.socket(socket.AF_INET, self.__protocol) as self.__client_socket:
                self.__client_socket.connect((self.__server, self.__server_port))
                self.__client_logic(self.__client_socket)
        except socket.error:
            print("Socket Error Occurred!")

    def start_udp_client(self) -> None:
        """
        Initialize and run the client socket using UDP.
        """
        with socket.socket(socket.AF_INET, self.__protocol) as self.__client_socket:
            self.__client_socket.settimeout(self.__timeout)
            self.__client_logic(
                self.__client_socket, (self.__server, self.__server_port)
            )


def test_server_logic(client_connection: socket, client_addr) -> None:
    """
    Server's logic function for class testing.

    Parameters:
    - client_connection (socket): The client connection socket.
    - client_addr (socket._RetAddress): The client address.

    Returns:
    - None
    """
    with client_connection:
        print(f"Thread started | Connected with {client_addr}")
        try:
            while client_connection:
                data = client_connection.recv(1024)
                client_connection.settimeout(30)
                client_connection.sendall(data)
        except socket.error:
            print(f"Disconnected from {client_addr}")


def test_client_logic(client_socket: socket) -> None:
    """
    Client's logic function for class testing.

    Parameters:
    - client (client_socket): The client socket instance.

    Returns:
    - None
    """
    with client_socket:
        try:
            client_socket.send(input("Message to send | ").encode("UTF-8"))
            print(f"Message received | {client_socket.recv(1024)}")
        except socket.error:
            client_socket.close()
            print("Disconnected")


def progress_bar(count, total, status="", length=30, color=Fore.YELLOW) -> None:
    """
    Display a progress bar.

    Parameters:
    - count (int): The current count.
    - total (int): The total count.
    - status (str): The status message.
    - length (int): The length of the progress bar.

    Returns:
    - None
    """

    init()
    filled_len = int(round(length * count / float(total)))
    load_bar = "■" * filled_len + "─" * (length - filled_len)
    print(
        f"[{color + load_bar + Fore.WHITE}]" + f"{count}/{total} - {status}", end="\r"
    )
    if count == total:
        print()


if __name__ == "__main__":
    # server = NetSockets(
    #     socket_type="server",
    #     protocol="udp",
    #     server_name="127.0.0.1",
    #     port=69,
    #     logic=test_server_logic
    # )
    # server.start_udp_server()

    client = NetSockets(
        socket_type="server",
        protocol="udp",
        server_name="127.0.0.1",
        port=69,
        logic=test_client_logic,
    )
    client.start_udp_client()
