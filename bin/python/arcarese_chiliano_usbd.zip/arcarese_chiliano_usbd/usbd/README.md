# usbd

![Language](https://img.shields.io/badge/Language-Python-yellowgreen?style=flat)
![Platform](https://img.shields.io/badge/OS%20platform%20supported-Windows-blue?style=flat)
![Testing](https://img.shields.io/badge/Test-Pass-green)
![Language](https://img.shields.io/badge/Spellcheck-Pass-green?style=flat)

## Consegna

Il pacchetto raccoglie alcune informazioni grazie all'eseguibile ``USBDeview.exe``, e le formatta in un
file ``ComputerName_unixTimeStamp_usbd.csv`` / ``ComputerName_unixTimeStamp_usbd.json``. In seguito l'idea prevede di raccogliere l'output da più host in una cartella condivisa e concatenare i file precedentemente
raccolti per poi depositarli in un database. Tutto questo sistema ha lo scopo di rafforzare la sicurezza
degli end point della rete rendendo le porte usb di ogni singolo terminale monitorabili.

## Descrizione

Il pacchetto presenta 4 programmi eseguibili:
  - ``usbd.bat`` → esegue ``usbd.py`` e ``USBDeview.exe`` e gestisce cartelle e file utili all'esesecuzione del pacchetto
  - ``usbd.py`` → formatta le informazioni fornite dal programma ``USBDeview.exe``
  - ``append_usbd.py`` → concatena i file nella cartella condivisa
  - ``USBDeview.exe`` → estrae le informazioni sulle porte usb dal registry
  - ``utility.py`` → si occupa della compilazione del file di log

## Requisiti

- python3 deve essere installato e raggiungibile tramite path (variabile d'ambiente)
- librerie:
  + pandas
  + icecream

## Esecuzione

Eseguire il file batch da linea comando all'interno del pacchetto in modo tale che il software riesca a
memorizzare l'output correttamente.
Inoltre è possibile attivare un filtro sulle interfacce umane (``HID``) come mouse, tastiere e terminali.
Comando parametrizzato che filtra i dispositivi ``HID``:

    usbd.py HID
Se non verrà dato alcun parametro l'applicazione non filtrerà le interfacce ``HID``.

## Anteprima Esecuzione
### CSV

``Unix Date;Record Date;User;Operating System;Device Name;Description;Device Type;Connected;Safe To Unplug;Disabled;USB Hub;Serial Number;Registry Time 1;Registry Time 2;VendorID;ProductID;Firmware Revision;USB Class;USB SubClass;USB Protocol;Computer Name;Vendor Name;ParentId Prefix;Service Name;Service Description;Driver Filename;Device Mfg;Power;Driver Description;Driver Version;Driver InfSection;Driver InfPath;Instance ID;Capabilities;First Install Time;Disconnect Time;``

``1670257362.5600665;2022-12-05 17:22:42.561067;HP EliteBook 745 G2 ;windows;Port_#0001.Hub_#0008;USB Composite Device;Unknown;No;Yes;No;No;;09/01/2022 16:46:08;03/01/2022 13:27:57;1a2c;0e24;1.10;00;00;00;DESKTOP-SI30CC2;;7&34f4891&0;usbccgp;@usb.inf,%GenericParent.SvcDesc%;Driver principale generico USB Microsoft;usbccgp.sys;(Controller host USB standard);;USB Composite Device;10.0.19041.488;Composite.Dev.NT;usb.inf;USB\VID_1A2C&PID_0E24\6&bde945b&1&1;Removable, SurpriseRemovalOK;;;``

### JSON

``{
  "Unix Date": "1670762712.5694406",
  "Record Date": "2022-12-11 13:45:12.569440",
  "User": "hp elitebook 745 g2",
  "Operating System": "windows",
  "Device Name": "Port_#0004.Hub_#0006",
  "Description": "Unknown USB Device (Device Descriptor Request Failed)",
  "Device Type": "Unknown",
  "Connected": "No",
  "Safe To Unplug": "No",
  "Disabled": "No",
  "USB Hub": "No",
  "Serial Number": "",
  "Registry Time 1": "27/08/2022 09:51:10",
  "Registry Time 2": "27/08/2022 09:51:10",
  "VendorID": "0000",
  "ProductID": "0002",
  "Firmware Revision": "0.00",
  "USB Class": "00",
  "USB SubClass": "00",
  "USB Protocol": "00",
  "Computer Name": "DESKTOP-SI30CC2",
  "Vendor Name": "",
  "ParentId Prefix": "",
  "Service Name": "",
  "Service Description": "",
  "Driver Filename": "",
  "Device Mfg": "(Controller host USB standard)",
  "Power": "",
  "Driver Description": "Unknown USB Device (Device Descriptor Request Failed)",
  "Driver Version": "10.0.19041.488",
  "Driver InfSection": "BADDEVICE.Dev.NT",
  "Driver InfPath": "usb.inf",
  "Instance ID": "USB\\VID_0000&PID_0002\\5&118b82aa&0&4",
  "Capabilities": "Removable, SilentInstall, RawDeviceOK",
  "First Install Time": "",
  "Disconnect Time": "",
  "\n": "\n"
}``


## Tags
Windows, Security, SIEM, USB, USBDeview, Data Management, System Hardening

## Author

Chiliano Arcarese
