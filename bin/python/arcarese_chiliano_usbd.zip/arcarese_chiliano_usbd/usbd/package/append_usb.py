#!/usr/bin/env python3


"""
Concatenate the formatted data in the shared folder
"""


import os
from icecream import ic


def concat_csv():

    """
    Concatenate the formatted data in the shared folder
    """

    data = ""
    index = 0
    shared_folder = "C:/Work/"
    append_usbd = os.path.join(shared_folder, "append_usbd.csv")

    # Iterate files in the shared folder
    for _, _, files in os.walk(shared_folder):
        for file in files:
            # Pass if is <append_usbd.csv>
            if file != "append_usbd.csv":

                with open(os.path.join(shared_folder, file), "r", encoding="UTF-8") as csv:
                    new_csv = []
                    # Read csv
                    csv = [i.split(';') for i in csv]
                    # Delete header if the file already exist or if isn't the first iteration
                    if os.path.exists(append_usbd) or index != 0:
                        ic(csv[0])
                        del csv[0]
                    # Format and save data
                    for row in csv:
                        new_csv.append(';'.join(row))
                    for string in new_csv:
                        data += string
                # Delete concatenated file
                os.remove(os.path.join(shared_folder, file))
            index += 1

    # Save data in a single file
    with open(append_usbd, "a", encoding="UTF-8") as usbd:
        usbd.write(data)


if __name__ == "__main__":

    ic.disable()

    concat_csv()
