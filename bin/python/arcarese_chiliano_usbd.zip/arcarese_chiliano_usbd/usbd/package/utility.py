#!/usr/bin/env python3

"""
This script trace the main program's execution.

    return: trace.log (file)
"""


import platform
import time
from datetime import datetime


def start_log():

    """
    Trace the start of the program in the .log file
    """
    # Open file in append
    with open("../log/trace.log", "a", encoding="UTF-8") as trace:
        # Writing date, platform, device name
        trace.write(f"{str(time.time())};{str(datetime.now())};" +
                    f"{platform.system().lower()};{platform.node()}" +
                    ";START\n")


def end_log():

    """
    Trace the end of the program in the .log file
    """
    # Open file in append
    with open("../log/trace.log", "a", encoding="UTF-8") as trace:
        # Writing date, platform, device name
        trace.write(f"{str(time.time())};{str(datetime.now())};" +
                    f"{platform.system().lower()};{platform.node()}" +
                    ";END\n")


if __name__ == "__main__":

    start_log()
    end_log()
