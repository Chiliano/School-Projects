#!/usr/bin/env python3


"""
Read and manipulate the output of USBDeview.exe in another csv file.

    Stima ore: 27
"""


import sys
import time
import json
import os.path
import platform
from datetime import datetime
from icecream import ic
from utility import start_log, end_log


def format_csv():

    """
    Parse the <ComputerName>_usbd_raw.csv file and substitute the separator (',' => ';')

        input: ..\\flussi\\<ComputerName>_usbd_raw.csv (file)
        output: ..\\flussi\\<ComputerName>_usbd_raw.csv (file)
    """

    with open(f"..\\flussi\\{platform.node()}_usbd_raw.csv", "r", encoding="UTF-8") as csv:

        # Put all the items on the file in a list
        data = [i.split('\t') for i in csv]
        new_data = []

        # Create rows with items separed by ';'
        for row in data:
            new_data.append(';'.join(row))

    with open(f"..\\flussi\\{platform.node()}_usbd_raw.csv", "w", encoding="UTF-8") as csv:

        # Write every formatted row in the file
        for row in new_data:
            csv.write(row)

def read_csv():

    """
    Read the csv file with the row dataset (USBDeview.exe output) and split it in a string list

        input: ..\\flussi\\<ComputerName>}_usbd_raw.csv (file)
        return: csv (list[])
    """

    ic.disable()

    with open(f"..\\flussi\\{platform.node()}_usbd_raw.csv", "r", encoding="UTF-8") as csv:

        # Put all the items on the file in a list
        csv = [i.split('\t') for i in csv]
        ic(csv)
        format_csv()

    return csv


def hid_filter(csv):

    """
    Delete istance when "Device Type" is "HID (Human Interface Device)"

        parameter: csv (list[])
        return: csv (list[])
    """

    ic.disable()

    # filter HID (Human Interface Device)
    csv = [row for i, row in enumerate(csv) if "HID (Human Interface Device)" not in row]
    ic(csv)

    return csv


def property_filter(csv):

    """
    Delete property when is in drop_list (list)

        parameter: csv (list[])
        return: csv (list[])
    """

    ic.disable()

    # Create list for proprieties deleting
    drop_list = ["Drive Letter", "WCID", "Hub / Port", "Product Name"]
    drop_list += ["Device Class", "Power", "Install Time", "First Install Time"]
    drop_list += ["Connect Time", "Disconnect Time\n", "USB Version", "Friendly Name"]
    drop_list += ["Driver Description"]

    ic(drop_list)
    ic(csv[0])

    index = 0
    # Delete the propreties in the csv
    for item in csv[0]:
        if item in drop_list:
            for row in csv:
                ic(index, item, row[index])
                del row[index]
        index += 1

    return csv


def add_device_info(csv):

    """
    Add properties to the dataset:
        • Unix Date
        • Record Date
        • User
        • Operating System

        parameter: csv (list[])
        return: csv (list[])
    """

    ic.disable()
    logged_user = get_logged_user()
    csv_lenght = len(csv)

    # Create 5 new columns
    unix_date_rows = [str(time.time()) for i in range(csv_lenght)]
    date_rows = [str(datetime.now()) for i in range(csv_lenght)]
    logged_user = logged_user.strip("\n")
    users_rows = [logged_user for i in range(csv_lenght)]
    so_rows = [platform.system().lower() for i in range(csv_lenght)]

    # add the new properties to the header
    if not os.path.exists(f"..\\flussi\\{platform.node()}_usbd.csv"):
        csv[0].insert(0, "Unix Date")
        csv[0].insert(1, "Record Date")
        csv[0].insert(2, "User")
        csv[0].insert(3, "Operating System")

    # add the new columns to the csv
    index = 1
    for _ in csv[1:-1]:
        index += 1
        csv[index].insert(0, unix_date_rows[index])
        csv[index].insert(1, date_rows[index])
        csv[index].insert(2, users_rows[index])
        csv[index].insert(3, so_rows[index])
        ic(unix_date_rows[index], index, csv[index])

    return csv


def write_csv(csv):

    """
    Verify file existance for header deletion and call writing_process()

        parameter: csv (list[])
    """

    ic.disable()

    # Verify file existance
    if os.path.exists(f"..\\flussi\\{platform.node()}_{str(time.time())}_usbd.csv"):

        # Delete header
        del csv[0]

        writing_process(csv)

    else:
        writing_process(csv)


def writing_process(csv_):

    """
    Write the dataset in the file: <ComputerName>_usbd.csv

        parameter: csv_ (list[])
    """

    file = f"..\\flussi\\{platform.node()}_{str(time.time())}_usbd.csv"
    with open(file, "a", encoding="UTF-8") as usbd:

        new_csv = []
        # Create the rows and append them in new_csv
        for row in csv_:
            new_csv.append(';'.join(row).strip("\n"))
        # Write all the rows in a file
        for item in new_csv:
            ic(item)
            usbd.write(item + "\n")


def get_logged_user():

    """
    Get logged user from the file: logged_user.txt (the file is an usbd.bat output)

        input: .\\logged_user.txt
        return: logged_user.read()
    """

    with open("logged_user.txt", "r", encoding="UTF-8") as logged_user:

        # Separate the ComputerName from the UserName
        user = logged_user.read().split('\\')
        # Return the username
        return user[1]


def  write_json(usbd):

    """
    Write the dataset in the file: <ComputerName>_usbd.json

        parameter: usbd (list[])
        output: ..\\flussi\\<ComputerName>_usbd.json
    """

    ic.disable()

    with open(f"..\\flussi\\{platform.node()}_usbd.json", "w", encoding="UTF-8") as json_file:

        for row in usbd[1:]:
            # Convert a row in a dictionary
            istance = {usbd[0][i]:item for i, item in enumerate(row)}
            # Write the istance on the file
            json_file.write(json.dumps(istance, indent=2))
            ic(istance)


if __name__ == "__main__":

    start_log()

    ic.enable()

    data_set = read_csv()
    print("■■", end="")

    # When parameter is HID
    if len(sys.argv) == 2:
        if sys.argv[1] == "HID":
            data_set = hid_filter(data_set)
            print("■■", end="")

    data_set = property_filter(data_set)
    print("■■", end="")

    data_set = add_device_info(data_set)
    print("■■■", end="")

    write_json(data_set)
    print("■■■■", end="")

    write_csv(data_set)
    print("■■>", end="")

    end_log()
