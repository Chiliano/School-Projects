import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;


public class QuintaCI_231011_ARCARESE_Client_validatore_JSON_v1 {

    private Socket clientSocket;
    private int PORT = 33333;

    public QuintaCI_231011_ARCARESE_Client_validatore_JSON_v1() {

        try {
            clientSocket = new Socket("localhost", PORT);
            this.send();

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void send() {

        try {
            Scanner scanner = new Scanner(System.in);

            DataOutputStream outputStream = new DataOutputStream(
                clientSocket.getOutputStream()
            );
            String str = scanner.nextLine();
            scanner.close();
            outputStream.writeUTF(str);     
            outputStream.flush();
            this.receve(clientSocket);
            outputStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    private String receve(Socket clientSocket) {

        String str = null;
        try {

            DataInputStream inputStream = new DataInputStream(
                clientSocket.getInputStream()
            ); 
            str = (String)inputStream.readUTF();
            System.out.println(str);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return str;
    }

    private void close() {
        try {
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        QuintaCI_231011_ARCARESE_Client_validatore_JSON_v1 client = new QuintaCI_231011_ARCARESE_Client_validatore_JSON_v1();

    }

}
