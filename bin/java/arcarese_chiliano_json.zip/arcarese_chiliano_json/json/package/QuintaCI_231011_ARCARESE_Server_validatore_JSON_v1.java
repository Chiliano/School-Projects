
import java.net.ServerSocket; 
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class QuintaCI_231011_ARCARESE_Server_validatore_JSON_v1 {

    private ServerSocket serverSocket;
    private int PORT = 33333;


    public QuintaCI_231011_ARCARESE_Server_validatore_JSON_v1() {

        try {
            serverSocket = new ServerSocket(PORT);
            Socket clientConnection = serverSocket.accept(); 
            this.receve(clientConnection);

        } catch (IOException e) {
            e.printStackTrace();
        } 
    }

    private void receve(Socket clientConnection) {

        String str = null;
        try {

            DataInputStream inputStream = new DataInputStream(
                clientConnection.getInputStream()
            );
            while(true) {
                str = (String)inputStream.readUTF();
                System.out.println("message:\n" + str);
                this.send(clientConnection, this.analisys(str));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void send(Socket clientSocket, boolean msg) {

        try {

            DataOutputStream outputStream = new DataOutputStream(
                clientSocket.getOutputStream()
            );
            String response = msg ? "Valido" : "Non Valido" ;
            outputStream.writeUTF(response); 
            outputStream.flush();
            outputStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean analisys(String str) {

        boolean bool = true;

        bool = str.length() > 2; 
        bool = str.startsWith("{") && str.endsWith("}");


        return bool;
    }

    private void close() {
        try {
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        QuintaCI_231011_ARCARESE_Server_validatore_JSON_v1 server = new QuintaCI_231011_ARCARESE_Server_validatore_JSON_v1();


    }
}
