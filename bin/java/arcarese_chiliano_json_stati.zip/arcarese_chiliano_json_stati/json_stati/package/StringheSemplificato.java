
import java.util.ArrayList;
import java.util.HashMap;

public class StringheSemplificato {
    public static void main(String[] args) {

        HashMap<String, ArrayList<HashMap<String, Object>>> transizioni = new HashMap<String, ArrayList<HashMap<String, Object>>>();
            ArrayList<HashMap<String, Object>> stringa_inizio = new ArrayList<HashMap<String, Object>>();
                HashMap<String, Object> inizio = new HashMap<String, Object>();
                    inizio.put("car", "\"");
                    inizio.put("ns", "stringa_interno");
                    inizio.put("t", 0);
            ArrayList<HashMap<String, Object>> stringa_interno = new ArrayList<HashMap<String, Object>>();
                HashMap<String, Object> interno_car = new HashMap<String, Object>();
                    interno_car.put("car", "[\\w]");
                    interno_car.put("ns", "stringa_interno");
                    interno_car.put("t", 0);
                HashMap<String, Object> interno_apice = new HashMap<String, Object>();
                    interno_apice.put("car", "\"");
                    interno_apice.put("ns", "stringa_fine");
                    interno_apice.put("t", true);
            ArrayList<HashMap<String, Object>> stringa_fine = new ArrayList<HashMap<String, Object>>();


        //inizializzazione del grafo di automa
        transizioni.put("inizio", stringa_inizio);
        transizioni.put("stringa_interno", stringa_interno);
        transizioni.put("fine_stringa", stringa_fine);


        Automa.validatore(transizioni, args[0]);

    }
}

