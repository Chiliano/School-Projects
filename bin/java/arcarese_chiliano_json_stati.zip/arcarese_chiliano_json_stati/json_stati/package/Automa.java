import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Automa {

    public static void validatore(HashMap<String, ArrayList<HashMap<String, Object>>> transizioni, String stringaDaValidare) {
        int i = 0;
        String statoCorrente = "inizio";
        boolean validitaStringa = true;
        boolean terminale = false;
        while (validitaStringa && i < stringaDaValidare.length()) {
            System.out.println("\nleggo carattere " + stringaDaValidare.charAt(i));
            for (String chiave : transizioni.keySet()) {
                ArrayList<HashMap<String,Object>> valore = transizioni.get(chiave);
                System.out.println("Key = " + chiave + ", Value = " + valore);
                validitaStringa = iterate(
                    statoCorrente,
                    validitaStringa,
                    terminale,
                    chiave,
                    valore,
                    stringaDaValidare,
                    i
                );
            }
            if (!validitaStringa) break;
        }
        validitaStringa = validitaStringa && terminale;
            System.out.println("\nvaliditaStringa: " + validitaStringa); 
    }


private static boolean iterate(
    String statoCorrente,
    boolean validitaStringa,
    boolean terminale,
    String stato,
    ArrayList<HashMap<String, Object>> condizioni,
    String stringaDaValidare,
    int i
) {
        boolean transizioneTrovata = false;
        statoCorrente = stato;
        Character carDaValidare = (Character) stringaDaValidare.charAt(i);
        Pattern pattern = Pattern.compile(carDaValidare.toString(), Pattern.CASE_INSENSITIVE);
        for (HashMap<String, Object> map : condizioni) {
            Matcher matcher = pattern.matcher((String) map.get("car"));
            if (matcher.find()) {
                statoCorrente = (String) map.get("ns");
                terminale = (boolean) map.get("t");
                transizioneTrovata = true;
            }
        }
        if (!transizioneTrovata) {
            validitaStringa = false;
            System.out.println("nessuna transizione accettata, stringa invalida");
            return false;
        }
        i++;
        return true;
    }
}