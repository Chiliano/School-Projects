# Chat
![GitHub](https://img.shields.io/badge/GitHub-Chiliano%20Arcarese-gray?&logo=GitHub)

![Testing](https://img.shields.io/badge/Test-√-green)
![Language](https://img.shields.io/badge/Spellcheck-√-green?style=flat)

![Language](https://img.shields.io/badge/Language-Python-yellowgreen?style=flat&logo=python&logoColor=yellowgreen)
![Version](https://img.shields.io/badge/Version-03.11.1-yellowgreen?style=flat&logo=python&logoColor=yellowgreen)

![Platform](https://img.shields.io/badge/OS%20platform%20supported-Windows-blue?style=flat&logo=windows&logoColor=blue)
![Platform](https://img.shields.io/badge/Not%20tested%20on-Linux-yellow?style=flat&logo=linux)

![Testing: 10/10](https://img.shields.io/badge/Pylint%20|%20Module:%20server.py-10.00-green)
![Testing: 10/10](https://img.shields.io/badge/Pylint%20|%20Module:%20client.py-10.00-green)
![Testing: 10/10](https://img.shields.io/badge/Pylint%20|%20Module:%20utility.py-10.00-green)

## Descrizione
Il package contiene tre moduli finalizzati ad offrire una `chat di gruppo` con la struttura `client` / `server`.

---

### Server
Il server gestisce le utenze scartando quelle non autorizzate.
Gli utenti autorizzati vengono salvati nell'array `_registered_users`, attributo della classe `Server`.

A ogni nuova connessione viene creato un `thread deamon` (background thread) che si occuperà di gestire un singolo client.

Alla ricezione di un messaggio il server si occuperà esclusivamente di mandare a ogni client connesso il messaggio ricevuto senza verificarne il contenuto.

#### Personalizzazioni:
Per `cambiare la rosa di utenti autorizzati` è necessario aggiungere un identificativo e `l'indirizzo IP` nel dizionario `_registered_users` nella classe Server.

---

### Client
Il client anchesso `multithread` gestisce i messaggi in I/O tramithe 2 foreground thread, ognuno dedicato all'input o all'output.

#### Personalizzazioni:
Per `cambiare nome utente` è necessario modificare il terzo parametro all'interno dell'if name del file `client.py`

Per `cambiare ip del server` è necessario modificare il primo parametro all'interno dell'if name del file `client.py`

---

### Log
Client e Server hanno un `sistema di logging` per la cattura e l'analisi degli errori. I record di log sono contenuti nella cartella log ed organizzati in `2 file `distinti.

## Requisiti
+ OS: Windows
+ Software: Python 3.11.1
+ Dependencies: contenute nel file `requirements.txt`

## Esecuzione
Per la corretta esecuzione del pacchetto è necessario che il server venga lanciato prima dei client.

Si consiglia lutilizzo di un `python virtual envirorment` (`venv`)

## Tags
Socket, python, client / server, chat, thread

## Author
Chiliano Arcarese