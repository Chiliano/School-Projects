/*
  This is the form's script in the file index.html.
  autor: Chiliano Arcarese 4CI
  version: 2.0
                                                      */

// Vars for validations and controls
var boolPasswordNumber = false;
var boolPasswordSpecial = false;
var boolPasswordUpper = false;
var passwordError = "";
var boolEmailDot = false;
var boolEmailAt = false;
var emailError = "* Please enter your email adress";
var boolCellNumber = false;
var cellNumberError = "* Please enter a valid cell number";
var boolDate = false;
var dateError = "* Please enter your date of birth";
var age;
var date;
// Form elements
var user = ["", "", "", "", "", ""];
var registred;


function registration(){

  // Store and check the data from the form

  // Default variable settings
  setDefaultSettings();

  // Getting form's elements
  for (let i = 0; i < user.length; i++) {
    user[i] = document.getElementById("form-box").elements[i].value;
  }

  // Validation of the form's password
  passwordValidation();

  // Age control
  ageControl();

  // Cell number validation
  if (user[3].length == 10 && boolCellNumber == false)
    boolCellNumber = true;

  // Email validation
  emailValidation();

  // Form result
  formResult();

}


function passwordValidation(){

  // Validation of the form's password

  // Charsets for password validation
  const specialChar = "\|!£$%&/()=?^{}[]§°#@-_.:,;*+\"\'";
  const upperChar = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const numbers = "0123456789";

  // Length check
  if (user[5].length >= 8){
    let password = user[5]
    for (let i in password){
      // Special char check
      for (let j in specialChar){
        if (specialChar[j] == password[i] && boolPasswordSpecial == false){
          boolPasswordSpecial = true;
        }
        else if (boolPasswordSpecial == false){
          passwordError = "* Please use a special character too (@,#,!...)";
        }
      }
      // Upper char check
      for (let j in upperChar){
        if (upperChar[j] == password[i] && boolPasswordUpper == false){
          boolPasswordUpper = true;
        }
        else if (boolPasswordUpper == false){
          passwordError = "* Please use a uppercase character too (A,B,C...)";
        }
      }
      // Number check
      for (let j in numbers){
        if (numbers[j] == password[i] && boolPasswordNumber == false){
          boolPasswordNumber = true;
        }
        else if (boolPasswordNumber == false){
          passwordError = "* Please use a number too (1,2,3...)";
        }
      }
    }
  }
  else{
    passwordError = "* Please type min 8 character";
  }
}


function ageControl(){

  // Age control

  date = user[2];
  if (date.length == 10){
    boolDate = true;
    if (2022 - parseInt(date.slice(0, 4)) >= 18){
      age = "Senior";
    }
    else{
      age = "Junior";
    }
  }
}


function emailValidation() {

  // Email validation

  for (let i in user[4]){
    let email = user[4];
    // "@" check
    if (email[i] == "@" && boolEmailAt == false){
      boolEmailAt = true;
    }
    else{
      emailError = "* Please enter a valid email, '@' missing";
    }
    // "." check
    if (email[i] == "." && boolEmailDot == false){
      boolEmailDot = true;
    }
    else{
      emailError = "* Please enter a valid email, '.' missing";
    }
  }
}


function formResult() {

  // Dysplayng the form result

  if (boolPasswordSpecial && boolPasswordNumber && boolPasswordUpper && boolEmailDot && boolEmailAt && boolCellNumber && boolCellNumber && boolDate){
    registred = "<h1><b>Wealcome!</b></h1><h2>" + user[0] + " " + user[1] + " " + age + "</h2><br>";
    registred += "<div id='registred'><h3>" + user[3] + "</h3><br><h3>" + user[4] + "</h3><br><h3>" + user[5] + "</h3></div>";
    registred += "<button id='cto'><a href='index.html'>Home</a></button>"
    document.getElementById("form-box").innerHTML = registred;
  }
  else{
    // Missing date of birth
    if (!boolDate){
      document.getElementById("user-date").style.borderBottom = "1px solid red";
      document.getElementById("error-date").innerHTML = dateError;
    }
    else{
      document.getElementById("user-date").style.borderBottom = "1px solid #ffffff";
      document.getElementById("error-date").innerHTML = "";
    }
    // Invalid cell number
    if (!boolCellNumber){
      document.getElementById("user-cell").style.borderBottom = "1px solid red";
      document.getElementById("error-cell-number").innerHTML = cellNumberError;
    }
    else{
      document.getElementById("user-cell").style.borderBottom = "1px solid #ffffff";
      document.getElementById("error-cell-number").innerHTML = "";
    }
    // Invalid password
    if (!(boolPasswordSpecial && boolPasswordNumber && boolPasswordUpper)){
      document.getElementById("user-password").style.borderBottom = "1px solid red";
      document.getElementById("error-password").innerHTML = passwordError;
    }
    else{
      document.getElementById("user-password").style.borderBottom = "1px solid #ffffff";
      document.getElementById("error-password").innerHTML = "";
    }
    // Invalid email
    if (!(boolEmailDot && boolEmailAt)){
      document.getElementById("user-email").style.borderBottom = "1px solid red";
      document.getElementById("error-email").innerHTML = emailError;
    }
    else{
      document.getElementById("user-email").style.borderBottom = "1px solid #ffffff";
      document.getElementById("error-email").innerHTML = "";
    }
  }
}


function setDefaultSettings() {
  boolPasswordNumber = false;
  boolPasswordSpecial = false;
  boolPasswordUpper = false;
  passwordError = "";
  boolEmailDot = false;
  boolEmailAt = false;
  emailError = "* Please enter your email adress";
  boolCellNumber = false;
  cellNumberError = "* Please enter a valid cell number";
  boolDate = false;
  dateError = "* Please enter your date of birth";
  age = "";
  date = "";
  // Form elements
  user = ["", "", "", "", "", ""];
}
