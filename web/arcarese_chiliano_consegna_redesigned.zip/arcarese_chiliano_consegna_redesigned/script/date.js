/*
  This script dysplay dinamically the date.
  autor: Chiliano Arcarese 4CI
  version: 1.0
                                            */


// the function will be execute in loop with the setted interval
id = setInterval(timeInfo, 1000);

function timeInfo(){

	// display current time, week day and date

	const weekDays = [ "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
	var out = new Date();

	// getting timestamp
	var time = out.getHours() + ":" + out.getMinutes()+ ":" + out.getSeconds();
	// getting day of the week
	var day = weekDays[out.getDay()];
	// getting date
	var date = out.getDate() + "/" + (out.getMonth() + 1) + "/" + out.getFullYear();

	// displayng all the info
	document.getElementById("date").innerHTML = day + " " + date + " " + time;

}

id = setInterval(currentTime, 1000);

function currentTime(){

	var out = new Date();
	document.getElementById("calendar-date").innerHTML = out.getHours() + ":" + out.getMinutes()+ ":" + out.getSeconds();

}
