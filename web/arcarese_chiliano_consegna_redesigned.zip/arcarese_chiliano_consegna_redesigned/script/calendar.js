/*
  This script dysplay a calendar.
  autor: Chiliano Arcarese 4CI
  version: 1.0.3
                                            */


function show(){
	// Show the calendar after an onclick event

	// Getting calendar and event trigger
	let calendar = document.getElementById("calendar");

	// If there isn't the calendar show it
	if (calendar.style.display === "none"){
		// Show calendar
		calendar.style.display = "block";
	}
	// If there is the calendar hide it
	else {
		// Hide calendar
		calendar.style.display = "none";
	}
}


function getFirstDayOfMonth(year, month) {
	// Return the Date object with the first day of the mounth

  return new Date(year, month, 1);
}


function calendar(){
	// Buoild the calendar

	// Get the first day of the current mouth
	const date = new Date();
	let firstDayCurrentMonth = getFirstDayOfMonth(
		date.getFullYear(),
  	date.getMonth(),
	);

  // Get the first day of the week in the current mounth
	let dayOfTheWeek = firstDayCurrentMonth.getDay();
	// Get all the calendar's cells
	let th = document.getElementsByTagName("th");

	// Iterate all the calendar
	for (let i = 7; i < th.length; i++) {
			// Write the days in the calendar's cells
			th[i].innerHTML = new Date(
				// Starting from the first day of the current mounth
				firstDayCurrentMonth.getFullYear(),
				firstDayCurrentMonth.getMonth(),
				// Add offset for every day
				((1 - (dayOfTheWeek - 1) + (i - 7)))
			).getDate();
	 }
}
