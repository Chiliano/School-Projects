/*
  This is the slider's script in the file index.html.
  autor: Chiliano Arcarese 4CI
  version: 1.0
                                                      */


const TEXT = [
    "<h1>Wealcome to my random webpage</h1><p>This is just a random exercise for website creations</p>",
    "<h1>Join us!</h1><p>Try to compile the form on the right</p>",
    "<h1>You need a calendar?</h1><p>Icon on the right!</p>"
  ]

var i = 0;

function nextImage(){

  // right slider's button: slide to the next image

  var text_box = document.getElementById("text");
  // go to the next image
  if (i < TEXT.length - 1){
    i += 1;
    text_box.innerHTML = TEXT[i];
  }
  // return to the first image
  else{
    i = 0;
    text_box.innerHTML = TEXT[i];
  }

}

function previousImage(){

  // left slider's button: slide to the previous image

  var text_box = document.getElementById("text");
  // go to the previous image

  if (i > 0){
    i -= 1;
    text_box.innerHTML = TEXT[i];
  }
  // return to the last image
  else{
    i = TEXT.length - 1;
    text_box.innerHTML = TEXT[i];
  }

}
