function animation(){
  var pos_b = 0;
  var pos_w = 0;
  let id_b = null;
  let id_w = null;
  var black_op = 1;
  var white_op = 1;
  const black = document.getElementById("black");
  const white = document.getElementById("white");
  clearInterval(id_b);
  clearInterval(id_w);
  id_b = setInterval(move_b, 50);
  id_w = setInterval(move_w, 50);

  function move_b(){

    if(pos_b <= 25){
      pos_b ++;
      black.style.right = pos_b + "%";
      black_op -= 0.04;
      black.style.opacity = black_op;
    }
  }

  function move_w(){

    if(pos_w <= 25){
      pos_w ++;
      white.style.left = pos_w + "%";
      white_op -= 0.04;
      white.style.opacity = white_op;
    }
  }
}

let id = null;
clearInterval(id);
id = setInterval(animation, 2500);

function sum(){
  var numbers = document.getElementsByTagName("input");
  var sumResult = document.getElementById("sum-result");
  var output = parseInt(numbers[0].value) + parseInt(numbers[1].value);
  sumResult.innerHTML = output;
}
